# Fill empty source_pre_tag / source_post_tag on vocabulary JSON items using the OpenAI API.
# Intended to run before translate_content_into_multiple_languages_target_expressions.py when
# tags are missing. Uses the English headword + example sentences (+ optional categories).
#
# Default: read translate_from/{words,expressions}/*.json and write translate_from_tagged/...
#   python fill_source_tags.py
# In-place overwrite:
#   python fill_source_tags.py --in-place
# Dry run (no writes):
#   python fill_source_tags.py --dry-run
# Skip items that already have source_post_tag set:
#   python fill_source_tags.py --skip-filled

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime
from typing import IO

import openai
from dotenv import load_dotenv

load_dotenv(override=True)

client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

MODEL = "gpt-5.4-mini"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INPUT = os.path.join(BASE_DIR, "translate_from")
DEFAULT_OUTPUT = os.path.join(BASE_DIR, "translate_from_tagged")

BATCH_SIZE = 20
MAX_RETRIES = 3
RETRY_DELAY = 5

LOG_FILE = os.path.join(BASE_DIR, "fill_source_tags.log")

# Closed vocabulary for source_post_tag (dictionary-style).
ALLOWED_POST_TAGS: frozenset[str] = frozenset(
    {
        "n.",
        "v.",
        "adj.",
        "adv.",
        "prep.",
        "conj.",
        "pron.",
        "interj.",
        "phrase",
        "num.",
        "det.",
        "other",
    }
)

_log_fh: IO[str] | None = None


def log(*args, end: str = "\n", flush: bool = False, **kwargs) -> None:
    print(*args, end=end, flush=flush, **kwargs)
    if _log_fh is not None:
        print(*args, end=end, **kwargs, file=_log_fh)
        if flush:
            _log_fh.flush()


def _system_prompt() -> str:
    allowed = ", ".join(sorted(ALLOWED_POST_TAGS))
    return f"""You assign English learner-dictionary style tags for vocabulary items.

Each input item has:
  - expression: the English headword or phrase (as in the learning unit)
  - examples: English example sentences showing how the item is used
  - categories: optional topic labels (hints only)

Decide the part of speech for the HEADWORD as used in this unit. Use the examples: they disambiguate noun vs verb (e.g. "shower" as a thing vs the action). If examples mix senses, pick the sense that best matches the headword as a single dictionary entry for this material.

Return a JSON object with key "items" — one object per input item, same order as input:
  "id": integer (must match input id)
  "source_post_tag": EXACTLY one of: {allowed}
  "source_pre_tag": usually an empty string. Use a short English prefix only when standard for this POS, e.g. "to " before a verb infinitive headword, or leave "".

Rules: output ALL items · do not change ids · valid JSON only · never leave source_post_tag empty."""


def _call_api(model_input: list[dict]) -> tuple[list[dict], str]:
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": _system_prompt()},
            {"role": "user", "content": json.dumps({"items": model_input}, ensure_ascii=False)},
        ],
        response_format={"type": "json_object"},
        temperature=0.1,
    )
    finish_reason = response.choices[0].finish_reason
    raw = response.choices[0].message.content
    items = json.loads(raw).get("items", [])
    return items, finish_reason


def _build_model_rows(
    batch: list[dict],
    indices: list[int],
) -> list[dict]:
    rows: list[dict] = []
    for local_i, global_idx in enumerate(indices):
        item = batch[global_idx]
        cats = item.get("categories") or []
        cat_names = [c.get("category_name", "") for c in cats if isinstance(c, dict)]
        rows.append(
            {
                "id": local_i,
                "expression": (item.get("source_expression") or "").strip(),
                "examples": [
                    (ex.get("source") or "").strip()
                    for ex in (item.get("examples") or [])
                    if isinstance(ex, dict)
                ],
                "categories": [c for c in cat_names if c],
            }
        )
    return rows


def _merge_tags(
    batch: list[dict],
    indices: list[int],
    tag_rows: list[dict],
) -> tuple[list[dict], list[int]]:
    """Apply tags to batch items at indices. Returns (updated_batch_slice, bad_local_ids)."""
    by_local = {r["id"]: r for r in tag_rows}
    bad: list[int] = []
    for local_i, global_idx in enumerate(indices):
        row = by_local.get(local_i)
        if not row:
            bad.append(local_i)
            continue
        post = (row.get("source_post_tag") or "").strip()
        if post not in ALLOWED_POST_TAGS:
            bad.append(local_i)
            continue
        pre = row.get("source_pre_tag")
        if pre is None:
            pre = ""
        if not isinstance(pre, str):
            bad.append(local_i)
            continue
        pre = pre.strip()
        if len(pre) > 32:
            pre = pre[:32]
        item = batch[global_idx]
        item["source_post_tag"] = post
        item["source_pre_tag"] = pre
    return batch, bad


def tag_batch_indices(
    batch: list[dict],
    indices: list[int],
    attempt: int = 1,
) -> None:
    """Fill tags for batch[indices] in place; retries failed local ids."""
    model_rows = _build_model_rows(batch, indices)
    try:
        result_items, finish_reason = _call_api(model_rows)
    except Exception as exc:
        if attempt < MAX_RETRIES:
            log(f"\n    ERROR (attempt {attempt}): {exc} — retrying…")
            time.sleep(RETRY_DELAY * attempt)
            return tag_batch_indices(batch, indices, attempt + 1)
        raise

    if finish_reason == "length":
        log("\n    WARNING: model output cut off (finish_reason=length).")

    _, bad_local = _merge_tags(batch, indices, result_items)

    if bad_local and attempt < MAX_RETRIES:
        log(
            f"\n    WARNING: {len(bad_local)} item(s) bad/missing tags (local ids {bad_local}) — retrying…"
        )
        time.sleep(RETRY_DELAY)
        retry_indices = [indices[i] for i in bad_local]
        # Single-item retries reduce cross-item confusion
        if len(retry_indices) == 1:
            tag_batch_indices(batch, retry_indices, attempt + 1)
        else:
            for gidx in retry_indices:
                tag_batch_indices(batch, [gidx], attempt + 1)
        return

    if bad_local:
        log(
            f"\n    WARNING: {len(bad_local)} item(s) still bad after retries "
            f"(local ids {bad_local}) — setting source_post_tag to 'other' where missing."
        )
        by_local = {r["id"]: r for r in result_items}
        for local_i, global_idx in enumerate(indices):
            item = batch[global_idx]
            if item.get("source_post_tag") in ALLOWED_POST_TAGS:
                continue
            row = by_local.get(local_i, {})
            post = (row.get("source_post_tag") or "").strip()
            item["source_post_tag"] = post if post in ALLOWED_POST_TAGS else "other"
            if item.get("source_pre_tag") is None:
                item["source_pre_tag"] = ""


def process_items(items: list[dict], skip_filled: bool) -> list[dict]:
    """Return a copy of items with tags filled (only mutates the copy's dicts)."""
    out = json.loads(json.dumps(items))  # deep copy
    to_tag: list[int] = []
    for i, it in enumerate(out):
        if skip_filled and str(it.get("source_post_tag", "")).strip():
            continue
        to_tag.append(i)

    if not to_tag:
        return out

    total_batches = (len(to_tag) + BATCH_SIZE - 1) // BATCH_SIZE
    for bnum, start in enumerate(range(0, len(to_tag), BATCH_SIZE), start=1):
        chunk_idx = to_tag[start : start + BATCH_SIZE]
        log(
            f"    [{bnum}/{total_batches}] tagging {len(chunk_idx)} item(s) …",
            end=" ",
            flush=True,
        )
        tag_batch_indices(out, chunk_idx)
        log("ok")
        time.sleep(0.2)
    return out


def process_file(
    input_path: str,
    output_path: str,
    *,
    dry_run: bool,
    skip_filled: bool,
) -> None:
    with open(input_path, encoding="utf-8") as f:
        items = json.load(f)
    if not isinstance(items, list):
        log(f"  SKIP (not a JSON array): {input_path}")
        return

    tagged = process_items(items, skip_filled=skip_filled)

    if dry_run:
        log(f"  DRY-RUN would write: {output_path}")
        return

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(tagged, f, ensure_ascii=False, indent=2)
    log(f"  → {output_path}")


def parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Fill source_pre_tag / source_post_tag on vocabulary JSON using OpenAI."
    )
    p.add_argument(
        "--input-dir",
        default=DEFAULT_INPUT,
        help=f"Base folder with words/ and expressions/ (default: {DEFAULT_INPUT})",
    )
    p.add_argument(
        "--output-dir",
        default=DEFAULT_OUTPUT,
        help=f"Output base when not --in-place (default: {DEFAULT_OUTPUT})",
    )
    p.add_argument(
        "--in-place",
        action="store_true",
        help="Overwrite JSON files in --input-dir",
    )
    p.add_argument("--dry-run", action="store_true", help="Do not write files")
    p.add_argument(
        "--skip-filled",
        action="store_true",
        help="Skip items that already have a non-empty source_post_tag",
    )
    p.add_argument(
        "--only",
        choices=("words", "expressions", "both"),
        default="both",
        help="Which subfolder to process",
    )
    p.add_argument(
        "files",
        nargs="*",
        help="Optional explicit JSON paths (if set, only these files are processed)",
    )
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    global _log_fh
    args = parse_args(argv or sys.argv[1:])

    _log_fh = open(LOG_FILE, "a", encoding="utf-8")
    try:
        run_start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log(f"\n{'#'*60}")
        log(f"# fill_source_tags started: {run_start}")
        log(f"# model={MODEL} dry_run={args.dry_run} in_place={args.in_place} skip_filled={args.skip_filled}")
        log(f"{'#'*60}")

        subfolders: list[str] = (
            ["words", "expressions"] if args.only == "both" else [args.only]
        )

        if args.files:
            for path in args.files:
                ap = os.path.abspath(path)
                if not os.path.isfile(ap):
                    log(f"Not found: {ap}")
                    continue
                if args.in_place:
                    outp = ap
                else:
                    rel = os.path.relpath(ap, os.path.abspath(args.input_dir))
                    outp = os.path.join(os.path.abspath(args.output_dir), rel)
                process_file(ap, outp, dry_run=args.dry_run, skip_filled=args.skip_filled)
        else:
            for sub in subfolders:
                in_dir = os.path.join(args.input_dir, sub)
                if not os.path.isdir(in_dir):
                    log(f"Folder not found, skipping: {in_dir}")
                    continue
                files = sorted(f for f in os.listdir(in_dir) if f.lower().endswith(".json"))
                log(f"\n{'='*60}\n  {sub}/  —  {len(files)} file(s)\n{'='*60}")
                for name in files:
                    in_path = os.path.join(in_dir, name)
                    if args.in_place:
                        out_path = in_path
                    else:
                        out_path = os.path.join(args.output_dir, sub, name)
                    log(f"\n  {name} ({os.path.basename(in_path)})")
                    process_file(
                        in_path,
                        out_path,
                        dry_run=args.dry_run,
                        skip_filled=args.skip_filled,
                    )

        log(f"\nDone. (finished: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')})")
    finally:
        _log_fh.close()
        _log_fh = None

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
