# This script will have to correct the empty target_expression field in the json files from the translate_to folder
# when the target_expression is empty and the target_pre_tag is not empty.
# The script will have to simply move the target_pre_tag to the target_expression field.
# the script will have to check all .json files in the translate_to folder and its subfolders.
# Example: {'source_language': 'EN', 'target_language': 'AR',
# 'source_pre_tag': '',  'source_expression': 'The bedroom', 'source_post_tag': '',
# 'target_pre_tag': 'غرفة النوم', 'target_expression': '', 'target_post_tag': '',
# 'examples': [{'source': 'The bedroom window faces east.', 'target': 'تواجه نافذة غرفة النوم الشرق.'}], 'categories': [{'category_name': 'Rooms'}, {'category_name': 'Bedroom'}]}

import json
import os

TRANSLATE_TO_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "translate_to"
)


def fix_file(path: str) -> int:
    """Fix items in one JSON file. Returns the number of items corrected."""
    with open(path, encoding="utf-8") as f:
        items = json.load(f)

    fixed = 0
    for item in items:
        pre_tag = item.get("target_pre_tag", "")
        expression = item.get("target_expression", "")
        if pre_tag and len(expression) == 0:
            item["target_expression"] = pre_tag
            item["target_pre_tag"] = ""
            fixed += 1

    if fixed:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)

    return fixed


def main() -> None:
    total_files = 0
    total_fixed_files = 0
    total_fixed_items = 0

    for root, _dirs, files in os.walk(TRANSLATE_TO_DIR):
        for filename in sorted(files):
            if not filename.lower().endswith(".json"):
                continue

            path = os.path.join(root, filename)
            fixed = fix_file(path)
            total_files += 1

            if fixed:
                rel = os.path.relpath(path, TRANSLATE_TO_DIR)
                print(f"  fixed {fixed:>4} item(s)  →  {rel}")
                total_fixed_files += 1
                total_fixed_items += fixed

    print(f"\nScanned {total_files} file(s).")
    if total_fixed_items:
        print(
            f"Fixed   {total_fixed_items} item(s) across {total_fixed_files} file(s)."
        )
    else:
        print("No items needed correction.")


if __name__ == "__main__":
    main()
