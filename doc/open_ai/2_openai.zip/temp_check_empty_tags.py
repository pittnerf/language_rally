# this script will check the empty tags in the json files from the translate_from/words and /expressions folders
# it will take all json files from the translate_from/words and /expressions folders
# will read all the itesm from the json files
# will check the following tags:
# - "source_expression"
# - "source" from the list of "examples"
# - "target_expression"
# - "target" from the list of "examples"
# If the tag is empty, it will display the file name and the tag name
# If the tag is not empty, it will display the file name and the tag name and the tag value
import json
import os

BASE_DIR = os.path.join(os.path.dirname(__file__), "translate_from")
SUBFOLDERS = ["words", "expressions"]

BASE_DIR = os.path.join(os.path.dirname(__file__), "translate_to")
SUBFOLDERS = [
    "AR/words",
    "AR/expressions",
    "ES/words",
    "ES/expressions",
    "FR/words",
    "FR/expressions",
    "HU/words",
    "HU/expressions",
    "IT/words",
    "IT/expressions",
    # "JA/words",
    # "JA/expressions",
    # "KO/words",
    # "KO/expressions",
    "PT/words",
    "PT/expressions",
    "RU/words",
    "RU/expressions",
    "RO/words",
    "RO/expressions",
    # "ZH/words",
    # "ZH/expressions",
]


def check_empty_tags_file(path: str):
    """Check the empty tags in the json file."""
    with open(path, encoding="utf-8") as f:
        items = json.load(f)

    for item in items:
        if 1 >= len(item.get("source_expression", "")):
            print("!!", path, "source_expression is too short", item)

        if 1 >= len(item.get("target_expression", "")):
            print("!!", path, "target_expression is too short", item)
        for ex in item.get("examples", []):
            if 1 >= len(ex.get("source", "")):
                print("!!", path, "examples//source is too short", item)
            if 1 >= len(ex.get("target", "")):
                print("!!", path, "examples//target is too short", item)


def main() -> None:

    for subfolder in SUBFOLDERS:
        folder = os.path.join(BASE_DIR, subfolder)
        if not os.path.isdir(folder):
            print(f"Folder not found, skipping: {folder}")
            continue

        json_files = sorted(
            f for f in os.listdir(folder) if f.lower().endswith(".json")
        )

        print(f"\n{'═' * 70}")
        print(f"  Folder: translate_from/{subfolder}  ({len(json_files)} files)")
        print(f"{'═' * 70}")

        for filename in json_files:
            path = os.path.join(folder, filename)
            check_empty_tags_file(path)


if __name__ == "__main__":
    main()
