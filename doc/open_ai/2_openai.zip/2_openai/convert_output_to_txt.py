files_to_convert = [
    "output/expressionsoutput_v5.json",
]
converted_txt_files = [file.replace(".json", ".txt") for file in files_to_convert]


def _safe_text(value):
    if value is None:
        return ""
    return str(value)


def _format_item(item):
    source_expr = _safe_text(item.get("source_expression"))
    target_expr = _safe_text(item.get("target_expression"))
    examples = item.get("examples") or []
    categories = item.get("categories") or []

    parts = ["L1=" + source_expr, "L2=" + target_expr]
    for idx in range(3):
        if idx < len(examples):
            ex = examples[idx] or {}
            ex_source = _safe_text(ex.get("source"))
            ex_target = _safe_text(ex.get("target"))
            parts.append(f"EX={ex_source}:::{ex_target}")

    all_categories = ""
    for idx in range(3):
        if idx < len(categories):
            ex_category = categories[idx] or ""
            if all_categories != "":
                all_categories = all_categories + ":::" + ex_category
            else:
                all_categories = ex_category

    if all_categories != "":
        parts.append(f"CAT={all_categories}")

    return "---".join(parts) + "---"


def convert_files_to_txt(files, output_files):
    import json

    if len(files) != len(output_files):
        raise ValueError("files and output_files must have the same length")

    for in_path, out_path in zip(files, output_files):
        with open(in_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError(f"Expected list in {in_path}, got {type(data).__name__}")

        lines = [_format_item(item) for item in data]
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))


if __name__ == "__main__":
    convert_files_to_txt(files_to_convert, converted_txt_files)
