# This script is used to correct the group name in the zip files.
# input folder: zip_input
# output folder: zip_output
# the zip files are named like this: package_....zip
# within the zip there is only one file called package_data.json
# the group name is the first number in the zip file name.
# the group name is "group_name": "A1 EN-DE words"
# it must be corrected to "EN-DE words A1"
# the new zip file must be saved in the output folder: zip_output
# the code page of the package_data.json must be kept the same (UTF-8)

import json
import os
import re
import zipfile

INPUT_DIR = os.path.join(os.path.dirname(__file__), "zip_input")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "zip_output")

# Matches a leading CEFR level like "A1", "B2", "C1" followed by a space
LEVEL_PREFIX_RE = re.compile(r"^([A-C][1-2])\s+(.+)$")


def fix_group_name(name: str) -> str:
    """Move a leading CEFR level prefix to the end: 'A1 EN-DE words' -> 'EN-DE words A1'."""
    m = LEVEL_PREFIX_RE.match(name)
    if m:
        return f"{m.group(2)} {m.group(1)}"
    return name


def process_zip(src_path: str, dst_path: str) -> None:
    with zipfile.ZipFile(src_path, "r") as zin:
        names = zin.namelist()
        if "package_data.json" not in names:
            print(f"  SKIP – no package_data.json in {os.path.basename(src_path)}")
            return

        raw_bytes = zin.read("package_data.json")

    # Work on the raw text to preserve original formatting and line endings.
    # Parse only to extract the old group_name value.
    data = json.loads(raw_bytes.decode("utf-8"))
    old_name = data.get("package", {}).get("group_name", "")
    new_name = fix_group_name(old_name)
    print(f"  {os.path.basename(src_path)}: '{old_name}' -> '{new_name}'")

    # Replace only the group_name value in the raw bytes, leaving everything else intact.
    old_snippet = f'"group_name": "{old_name}"'.encode("utf-8")
    new_snippet = f'"group_name": "{new_name}"'.encode("utf-8")
    updated_bytes = raw_bytes.replace(old_snippet, new_snippet, 1)

    with zipfile.ZipFile(dst_path, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        zout.writestr("package_data.json", updated_bytes)


def main() -> None:
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    zip_files = [f for f in os.listdir(INPUT_DIR) if f.lower().endswith(".zip")]
    if not zip_files:
        print("No zip files found in", INPUT_DIR)
        return

    for filename in sorted(zip_files):
        src = os.path.join(INPUT_DIR, filename)
        dst = os.path.join(OUTPUT_DIR, filename)
        process_zip(src, dst)

    print(f"\nDone – {len(zip_files)} file(s) written to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
