# List one-time products from the Google Play Store for the LanguageRally app.
import argparse
import json
import sys

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

PACKAGE_NAME = "com.languagerally.app"
SERVICE_ACCOUNT_FILE = "./google_cloud/languagerally-84a7af1abf0c.json"
DEFAULT_LISTING_LOCALE = "en-GB"
PAGE_SIZE = 1000


def build_service():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE,
        scopes=["https://www.googleapis.com/auth/androidpublisher"],
    )
    return build("androidpublisher", "v3", credentials=credentials)


def listing_for_product(product: dict, locale: str = DEFAULT_LISTING_LOCALE) -> dict:
    listings = product.get("listings") or []
    for listing in listings:
        if listing.get("languageCode") == locale:
            return listing
    return listings[0] if listings else {}


def purchase_option_states(product: dict) -> list[str]:
    states: list[str] = []
    for option in product.get("purchaseOptions") or []:
        option_id = option.get("purchaseOptionId", "?")
        state = option.get("state", "UNKNOWN")
        states.append(f"{option_id}:{state}")
    return states


def summarize_product(product: dict) -> dict:
    listing = listing_for_product(product)
    return {
        "productId": product.get("productId", ""),
        "title": listing.get("title", ""),
        "description": listing.get("description", ""),
        "listingLocale": listing.get("languageCode", ""),
        "purchaseOptions": purchase_option_states(product),
    }


def list_one_time_products(service) -> list[dict]:
    products: list[dict] = []
    page_token = None

    while True:
        kwargs = {"packageName": PACKAGE_NAME, "pageSize": PAGE_SIZE}
        if page_token:
            kwargs["pageToken"] = page_token

        response = service.monetization().onetimeproducts().list(**kwargs).execute()
        products.extend(response.get("oneTimeProducts") or [])
        page_token = response.get("nextPageToken")
        if not page_token:
            break

    return products


def product_ids(products: list[dict]) -> list[str]:
    ids = [product.get("productId", "") for product in products]
    return sorted(id for id in ids if id)


def print_names_only(products: list[dict]) -> None:
    ids = product_ids(products)
    for product_id in ids:
        print(product_id)
    print(f"\nTotal: {len(ids)}")


def print_summary(products: list[dict]) -> None:
    summaries = [summarize_product(product) for product in products]
    summaries.sort(key=lambda item: item["productId"])

    print(f"Found {len(summaries)} one-time product(s) for {PACKAGE_NAME}:\n")
    for item in summaries:
        options = ", ".join(item["purchaseOptions"]) or "(no purchase options)"
        print(f"- {item['productId']}")
        print(f"  title: {item['title']}")
        print(f"  locale: {item['listingLocale']}")
        print(f"  purchase options: {options}")
        print()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="List one-time products from the Google Play Store."
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print full API response objects as JSON.",
    )
    parser.add_argument(
        "--output",
        metavar="FILE",
        help="Write JSON output to a file (implies --json).",
    )
    parser.add_argument(
        "--names-only",
        action="store_true",
        help="Print only product IDs (one per line) and the total count.",
    )
    args = parser.parse_args()

    try:
        service = build_service()
        products = list_one_time_products(service)
    except HttpError as e:
        try:
            payload = json.loads((e.content or b"{}").decode("utf-8"))
            message = (payload.get("error") or {}).get("message", "") or str(e)
        except Exception:
            message = str(e)
        print(f"Google Play API error: {message}", file=sys.stderr)
        raise SystemExit(1) from e

    if args.names_only:
        print_names_only(products)
    elif args.json or args.output:
        payload = {
            "packageName": PACKAGE_NAME,
            "count": len(products),
            "oneTimeProducts": products,
        }
        text = json.dumps(payload, indent=2, ensure_ascii=False)
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(text)
                f.write("\n")
            print(f"Wrote {len(products)} product(s) to {args.output}")
        else:
            print(text)
    else:
        print_summary(products)


if __name__ == "__main__":
    main()
