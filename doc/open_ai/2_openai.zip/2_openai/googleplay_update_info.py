# This script will update/add the information on products in the Google Play Store based on the zip files in the local_zip_folder
# fields to be handled based on a zip file with the name "pkg_en_ar_A1_Basic_health_feeling_sick_doctor.zip":
# product name: e.g. English-Arab A1 Basic health feeling sick doctor (so the <language1> - <language2> <level> <title> )
# product id: e.g.  pkg_en_ar_a1_basic_health_feeling_sick_doctor (so the name of the zip file in small caps, and without the extension)
# product description: e.g "Vocabulary and expressions in English and Arab languages for A1 level, category: Basic health feeling sick doctor"
# labels: e.g. ["english", "arabic", "a1", "basic health feeling sick doctor"] - the last label contains the product title in small caps
# Content Rating: e.g. Everyone
# countries: all countries
# Purchase options:
#     one-time purchase: yes
#     labels: e.g. ["anglish", "arabic", "a1", "basic health feeling sick doctor"] - the last label contains the product title in small caps
#     content type: digital content
#     product price: e.g. 1.00 USD
#     product currency: e.g. USD
#     countries: all countries
import os
import json

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Beállítások
PACKAGE_NAME = "com.languagerally.app"  # Az appod egyedi azonosítója
SERVICE_ACCOUNT_FILE = "./google_cloud/languagerally-84a7af1abf0c.json"  # A Google Cloud-ból letöltött kulcs
LOCAL_ZIP_FOLDER = "./firebase/zips"
# Play requires a listing for the app's default language. Your account/app expects en-GB.
DEFAULT_LISTING_LOCALE = "en-GB"
DEFAULT_CURRENCY = "USD"
DEFAULT_PRICE_MICROS = "1000000"  # 1.00 USD

# We’ll compute region prices dynamically via monetization.convertRegionPrices,
# which also returns the required `regionVersion` to use when patching products.
# Docs: https://developers.google.com/android-publisher/api-ref/rest/v3/monetization/convertRegionPrices

# API inicializálása
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/androidpublisher"]
)
service = build("androidpublisher", "v3", credentials=credentials)
LANGUAGE_CODE_TO_NAME: dict[str, str] = {
    "ar": "Arabic",
    "bg": "Bulgarian",
    "cs": "Czech",
    "da": "Danish",
    "de": "German",
    "el": "Greek",
    "en": "English",
    "es": "Spanish",
    "et": "Estonian",
    "fa": "Persian",
    "fi": "Finnish",
    "fr": "French",
    "he": "Hebrew",
    "hi": "Hindi",
    "hr": "Croatian",
    "hu": "Hungarian",
    "id": "Indonesian",
    "it": "Italian",
    "ja": "Japanese",
    "ko": "Korean",
    "lt": "Lithuanian",
    "lv": "Latvian",
    "nl": "Dutch",
    "no": "Norwegian",
    "pl": "Polish",
    "pt": "Portuguese",
    "ro": "Romanian",
    "ru": "Russian",
    "sk": "Slovak",
    "sl": "Slovenian",
    "sv": "Swedish",
    "th": "Thai",
    "tr": "Turkish",
    "uk": "Ukrainian",
    "vi": "Vietnamese",
    "zh": "Chinese",
}


def language_name(language_code: str) -> str:
    code = (language_code or "").strip().lower()
    if not code:
        return ""
    return LANGUAGE_CODE_TO_NAME.get(code, code)


def clamp(s: str, max_len: int) -> str:
    s = (s or "").strip()
    if len(s) <= max_len:
        return s
    return (s[: max(0, max_len - 1)].rstrip() + "…") if max_len > 1 else s[:max_len]


def build_title(language_1: str, language_2: str, level: str, category: str) -> str:
    # Example: "English-Arabic A1 Basic health feeling sick doctor"
    return clamp(f"{language_1}-{language_2} {level} {category}", 55)


def build_description(
    language_1: str, language_2: str, level: str, category: str
) -> str:
    # Example:
    # "Vocabulary and expressions in English and Arabic languages for A1 level, category: Basic health feeling sick doctor"
    return clamp(
        f"Vocabulary and expressions in {language_1} and {language_2} languages "
        f"for {level} level, category: {category}",
        200,
    )


def price_money(currency_code: str, units: str, nanos: int = 0) -> dict:
    return {"currencyCode": currency_code, "units": str(units), "nanos": int(nanos)}


def get_region_pricing_from_usd(
    usd_units: str = "1",
    usd_nanos: int = 0,
) -> tuple[str, dict[str, dict], dict]:
    """
    Returns:
      - regions_version (e.g. "2025/01")
      - region_prices: map regionCode -> Money (tax inclusive) for that region
      - other_regions_price: {usdPrice: Money, eurPrice: Money}
    """
    resp = (
        service.monetization()
        .convertRegionPrices(
            packageName=PACKAGE_NAME,
            body={"price": price_money("USD", usd_units, usd_nanos)},
        )
        .execute()
    )
    regions_version = ((resp.get("regionVersion") or {}).get("version")) or ""
    converted_region_prices = resp.get("convertedRegionPrices") or {}
    region_prices: dict[str, dict] = {}
    for region_code, info in converted_region_prices.items():
        price = (info or {}).get("price")
        if price:
            region_prices[region_code] = price
    other_regions_price = resp.get("convertedOtherRegionsPrice") or {}
    return regions_version, region_prices, other_regions_price


def upsert_one_time_product(product_id: str, title: str, description: str) -> None:
    try:
        regions_version, region_prices, other_regions_price = get_region_pricing_from_usd(
            usd_units="1", usd_nanos=0
        )
        if not regions_version:
            raise RuntimeError("convertRegionPrices did not return regionVersion.version")

        regional_configs = [
            {
                "regionCode": region_code,
                "price": money,
                "availability": "AVAILABLE",
            }
            for region_code, money in sorted(region_prices.items())
        ]

        body = {
            "packageName": PACKAGE_NAME,
            "productId": product_id,
            "listings": [
                {
                    "languageCode": DEFAULT_LISTING_LOCALE,
                    "title": title,
                    "description": description,
                }
            ],
            "purchaseOptions": [
                {
                    "purchaseOptionId": "buy-default",
                    # Explicitly set pricing/availability for all known regions.
                    "regionalPricingAndAvailabilityConfigs": regional_configs,
                    # Provide a default price for "Other regions" (countries without local currency).
                    "newRegionsConfig": {
                        "usdPrice": other_regions_price.get("usdPrice")
                        or price_money("USD", "1", 0),
                        "eurPrice": other_regions_price.get("eurPrice")
                        or price_money("EUR", "1", 0),
                        "availability": "AVAILABLE",
                    },
                    "buyOption": {
                        "legacyCompatible": True,
                        "multiQuantityEnabled": False,
                    },
                }
            ],
        }

        # Discovery doc: path params packageName + productId; query param
        # regionsVersion.version -> kwarg regionsVersion_version for this client.
        service.monetization().onetimeproducts().patch(
            packageName=PACKAGE_NAME,
            productId=product_id,
            allowMissing=True,
            updateMask="listings,purchaseOptions",
            regionsVersion_version=regions_version,
            body=body,
        ).execute()

        # Purchase options often start in DRAFT/INACTIVE. Activate it so it's purchasable.
        service.monetization().onetimeproducts().purchaseOptions().batchUpdateStates(
            packageName=PACKAGE_NAME,
            productId=product_id,
            body={
                "requests": [
                    {
                        "activatePurchaseOptionRequest": {
                            "packageName": PACKAGE_NAME,
                            "productId": product_id,
                            "purchaseOptionId": "buy-default",
                            "latencyTolerance": "PRODUCT_UPDATE_LATENCY_TOLERANCE_LATENCY_SENSITIVE",
                        }
                    }
                ]
            },
        ).execute()
        print(f"Upserted one-time product in Play Store: {product_id}")
    except HttpError as e:
        # Provide more actionable errors for common migration/enablement issues.
        status = getattr(e, "status_code", None) or getattr(
            getattr(e, "resp", None), "status", None
        )
        try:
            payload = json.loads((e.content or b"{}").decode("utf-8"))
        except Exception:
            payload = {}

        message = (payload.get("error") or {}).get("message", "") or str(e)
        if status == 403 and "migrate to the new publishing api" in message.lower():
            raise RuntimeError(
                "Play Console requires the new publishing API for products. "
                "This script uses monetization.onetimeproducts; if you still see this error, "
                "your installed google-api-python-client discovery may be outdated."
            ) from e

        details = (payload.get("error") or {}).get("details", []) or []
        error_info = next(
            (d for d in details if d.get("@type") == "type.googleapis.com/google.rpc.ErrorInfo"),
            None,
        )
        if (error_info or {}).get("reason") == "SERVICE_DISABLED":
            activation_url = ((error_info or {}).get("metadata") or {}).get("activationUrl")
            raise RuntimeError(
                "Google Play Android Developer API is disabled for the GCP project of this service account. "
                f"Enable it and retry. Activation URL: {activation_url or '(not provided)'} "
                f"Original message: {message}"
            ) from e

        raise


def upload_to_play():
    files = [f for f in os.listdir(LOCAL_ZIP_FOLDER) if f.endswith(".zip")]

    for file_name in files:
        raw_name = os.path.splitext(file_name)[0]
        product_id = raw_name.lower()
        parts = raw_name.split("_")

        # Példa: ["pkg", "en", "ar", "A1", "Animals"]
        if len(parts) < 5:
            print(f"SKIP (unexpected filename format): {file_name}")
            continue

        # full category/title starting from parts[4]
        category = " ".join(parts[4:])
        language_code_1 = parts[1].lower()
        language_code_2 = parts[2].lower()
        language_1 = language_name(language_code_1)
        language_2 = language_name(language_code_2)
        level = parts[3].upper()

        listing_title = build_title(language_1, language_2, level, category)
        listing_description = build_description(language_1, language_2, level, category)

        try:
            upsert_one_time_product(product_id, listing_title, listing_description)
        except Exception as e:
            print(f"Error for {product_id}: {e}")


if __name__ == "__main__":
    upload_to_play()
