# this python script will translate the categories in the file: translate_from/categories/categories_en.txt
# with the help of the openai api into the following languages:
# Spanish,
# French,
# German,
# Italian,
# Japanese,
# Chinese,
# Korean,
# Portuguese,
# Russian,
# Arabic,
# Romanian,
# Hungarian
# Dutch,
# Swedish,
# Norwegian,
# Danish,
# Finnish,
# Hindi,
# Turkish,
# Vietnamese,
# Thai,
# Indonesian,
# Malay,
# Filipino,
# Turkish,
# Hebrew,
# The script will read the input file with the English categories separated by commas
# The output will be a file with the name categories_<language_code>.json, where <language_code> is the code of the language,
# The file will contain a list of objects, each object will have the following fields:
# - "category_name_en": the name of the category in English
# - "category_name": the translated name of the category in the language <language_code>
# The script will use the openai api to translate the categories

import json
import os
import time

import openai
from dotenv import load_dotenv

load_dotenv(override=True)

client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

MODEL = "gpt-4o-mini"

INPUT_FILE = os.path.join(
    os.path.dirname(__file__), "translate_from", "categories", "categories_en.txt"
)
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "translate_from", "categories")

# (lang_code, lang_name) — Turkish deduplicated from the original list
LANGUAGES: list[tuple[str, str]] = [
    ("es", "Spanish"),
    ("fr", "French"),
    ("de", "German"),
    ("it", "Italian"),
    ("ja", "Japanese"),
    ("zh", "Chinese"),
    ("ko", "Korean"),
    ("pt", "Portuguese"),
    ("ru", "Russian"),
    ("ar", "Arabic"),
    ("ro", "Romanian"),
    ("hu", "Hungarian"),
    ("nl", "Dutch"),
    ("sv", "Swedish"),
    ("no", "Norwegian"),
    ("da", "Danish"),
    ("fi", "Finnish"),
    ("hi", "Hindi"),
    ("tr", "Turkish"),
    ("vi", "Vietnamese"),
    ("th", "Thai"),
    ("id", "Indonesian"),
    # ("ms", "Malay"),
    # ("fil", "Filipino"),
    # ("he", "Hebrew"),
]

BATCH_SIZE = 150  # categories per API call
RETRY_DELAY = 5  # seconds between retries on API error
MAX_RETRIES = 3


def read_categories(path: str) -> list[str]:
    with open(path, encoding="utf-8") as f:
        text = f.read()
    return [c.strip() for c in text.split(",") if c.strip()]


def translate_batch(
    categories: list[str], lang_name: str, attempt: int = 1
) -> dict[str, str]:
    items = "\n".join(f"- {c}" for c in categories)
    prompt = (
        f"Translate the following English category names to {lang_name}.\n"
        "Return ONLY a JSON object where every key is the original English name "
        "and the value is its translation. Do not add explanations, do not change keys.\n\n"
        f"Category names:\n{items}"
    )
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a precise multilingual translator. "
                        "Always respond with valid JSON only."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            response_format={"type": "json_object"},
            temperature=0.1,
        )
        return json.loads(response.choices[0].message.content)
    except Exception as exc:
        if attempt < MAX_RETRIES:
            print(f"    Retry {attempt}/{MAX_RETRIES} after error: {exc}")
            time.sleep(RETRY_DELAY * attempt)
            return translate_batch(categories, lang_name, attempt + 1)
        raise


def translate_language(categories: list[str], lang_code: str, lang_name: str) -> None:
    output_path = os.path.join(OUTPUT_DIR, f"categories_{lang_code}.json")

    if os.path.exists(output_path):
        print(f"  [{lang_code}] {lang_name} – already exists, skipping.")
        return

    print(f"\n[{lang_code}] Translating to {lang_name} …")
    all_translations: dict[str, str] = {}
    total_batches = (len(categories) + BATCH_SIZE - 1) // BATCH_SIZE

    for idx in range(0, len(categories), BATCH_SIZE):
        batch = categories[idx : idx + BATCH_SIZE]
        batch_num = idx // BATCH_SIZE + 1
        print(
            f"  Batch {batch_num}/{total_batches} ({len(batch)} items) …",
            end=" ",
            flush=True,
        )
        translations = translate_batch(batch, lang_name)
        all_translations.update(translations)
        print("ok")
        time.sleep(0.3)  # gentle rate-limit buffer

    # Warn about any missing translations
    missing = [c for c in categories if c not in all_translations]
    if missing:
        print(
            f"  WARNING: {len(missing)} categories not returned by model, kept in English."
        )

    result = [
        {
            "category_name_en": cat,
            "category_name": all_translations.get(cat, cat),
        }
        for cat in categories
    ]

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"  Written: {output_path}  ({len(result)} entries)")


def main() -> None:
    categories = read_categories(INPUT_FILE)
    print(f"Loaded {len(categories)} categories from:\n  {INPUT_FILE}\n")

    for lang_code, lang_name in LANGUAGES:
        translate_language(categories, lang_code, lang_name)

    print("\nAll done.")


if __name__ == "__main__":
    main()
