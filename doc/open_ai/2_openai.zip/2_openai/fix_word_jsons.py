# This program will take all json files from the json_input folder correct them and save the output to the json_output folder
# the code page of the files (UTF-8)  must be kept the same
# the files must be corrected in the following way:
# - the text "source_word" must be replaced with "source_expression"
# - the text "target_word" must be replaced with "target_expression"
# - the name of the files must be kept the same


import os


def process_json_files(input_dir, output_dir):
    # 1. Create the output folder if it doesn't already exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created directory: {output_dir}")

    # 2. Iterate through all files in the input folder
    # 1. Get a list of all files in the directory
    all_files = os.listdir(input_dir)

    # 2. Filter for JSON files and create full paths for sorting
    json_files = [f for f in all_files if f.endswith(".json")]

    # 3. Sort the list by creation time (Older files first)
    # os.path.getctime returns the creation time as a timestamp
    json_files.sort(key=lambda x: os.path.getctime(os.path.join(input_dir, x)))

    # 4. Now run the loop on the sorted list
    for filename in json_files:
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)

        try:
            # 3. Read the file using UTF-8 encoding
            with open(input_path, "r", encoding="utf-8") as file:
                content = file.read()

            # 4. Perform the required text replacements
            # This replaces the strings globally within the file
            corrected_content = content.replace("source_word", "source_expression")
            corrected_content = corrected_content.replace(
                "target_word", "target_expression"
            )

            # 5. Save the output to the new folder, keeping UTF-8 encoding
            with open(output_path, "w", encoding="utf-8") as file:
                file.write(corrected_content)

            print(f"Successfully processed: {filename}")

        except Exception as e:
            print(f"Failed to process {filename}: {e}")


if __name__ == "__main__":
    # Define your folder paths here
    INPUT_FOLDER = "json_input"
    OUTPUT_FOLDER = "json_output"

    # Run the program
    process_json_files(INPUT_FOLDER, OUTPUT_FOLDER)
