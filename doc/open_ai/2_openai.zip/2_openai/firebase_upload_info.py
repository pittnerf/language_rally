# this script will upload the information based on the zip files in the local_zip_folder into the firebase database
# collection name: store_products
# database name: languagerally

import os

import firebase_admin
from firebase_admin import credentials
from google.cloud import firestore

# 1. Inicializálás a JSON kulccsal
service_account_path = "firebase/languagerally-firebase-adminsdk-fbsvc-06bd60e242.json"
cred = credentials.Certificate(service_account_path)
firebase_admin.initialize_app(cred)

# Firestore target configuration
expected_project_id = "languagerally"
firestore_database_id = "languagerally"  # non-default database id (not "(default)")

# Fail fast if the service account points at the wrong project
actual_project_id = getattr(cred, "project_id", None)
if actual_project_id != expected_project_id:
    raise RuntimeError(
        "Service account project_id mismatch. "
        f"Expected '{expected_project_id}', got '{actual_project_id}'. "
        f"Check: {service_account_path}"
    )

# Open the Firestore database (non-default database id)
db = firestore.Client(
    project=expected_project_id,
    credentials=cred.get_credential(),
    database=firestore_database_id,
)

# Beállítások
local_zip_folder = "./firebase/zips"  # A mappa, ahol a ZIP fájljaid vannak
collection_name = "store_products"


LANGUAGE_CODE_TO_NAME: dict[str, str] = {
    "ar": "Arabic",
    "bg": "Bulgarian",
    "cs": "Czech",
    "da": "Danish",
    "de": "German",
    "el": "Greek",
    "en": "English",
    "es": "Spanish",
    "et": "Estonian",
    "fa": "Persian",
    "fi": "Finnish",
    "fr": "French",
    "he": "Hebrew",
    "hi": "Hindi",
    "hr": "Croatian",
    "hu": "Hungarian",
    "id": "Indonesian",
    "it": "Italian",
    "ja": "Japanese",
    "ko": "Korean",
    "lt": "Lithuanian",
    "lv": "Latvian",
    "nl": "Dutch",
    "no": "Norwegian",
    "pl": "Polish",
    "pt": "Portuguese",
    "ro": "Romanian",
    "ru": "Russian",
    "sk": "Slovak",
    "sl": "Slovenian",
    "sv": "Swedish",
    "th": "Thai",
    "tr": "Turkish",
    "uk": "Ukrainian",
    "vi": "Vietnamese",
    "zh": "Chinese",
}


def language_name(language_code: str) -> str:
    code = (language_code or "").strip().lower()
    if not code:
        return ""
    return LANGUAGE_CODE_TO_NAME.get(code, code)


def upload_zips():
    files = [f for f in os.listdir(local_zip_folder) if f.endswith(".zip")]
    print(f"Találtam {len(files)} fájlt. Indul a feltöltés...")

    # Batch (kötegelt) feltöltés a sebességért (max 500 írás / batch)
    # Use a lower cap to leave room if you later add extra writes per file.
    max_writes_per_batch = 450
    batch = db.batch()
    writes_in_batch = 0
    count = 0
    for file_name in files:
        # Fájlnév kiterjesztés nélkül (pl. pkg_en_ar_A1_Animals)
        raw_name = os.path.splitext(file_name)[0]

        # Dokumentum ID (kisbetűssé alakítva, ahogy a példádban kérted)
        doc_id = raw_name.lower()

        # Dokumentum referencia
        doc_ref = db.collection(collection_name).document(doc_id)

        # Adatstruktúra összeállítása a példád alapján
        # Itt egy kis logikával szétszedjük a fájlnevet (feltételezve a fix sorrendet)
        parts = raw_name.split("_")
        # Példa: ["pkg", "en", "ar", "A1", "Animals"]
        if len(parts) < 5:
            print(f"SKIP (unexpected filename format): {file_name}")
            continue

        # we need the full title starting with parts[4]
        title = parts[4]
        for i in range(5, len(parts)):
            title += f" {parts[i]}"
        language_code_1 = parts[1].lower()
        language_code_2 = parts[2].lower()
        language_1 = language_name(language_code_1)
        language_2 = language_name(language_code_2)

        data = {
            "description": f"Vocabulary and expressions for {language_2} learners: {title}",
            "groupName": f"{language_1} - {language_2}",
            "isActive": False,
            "languageCode1": language_code_1,  # en
            "languageCode2": language_code_2,  # ar
            "level": parts[3].upper(),  # A1
            "productId": doc_id,  # pkg_en_ar_a1_animals
            "storagePath": file_name,  # pkg_en_ar_A1_Animals.zip
            "title": f"{title} ({parts[1].upper()}-{parts[2].upper()}, {parts[3].upper()})",
        }

        batch.set(doc_ref, data)
        writes_in_batch += 1
        print(f"Hozzáadva a batch-hez: {doc_id}")

        if writes_in_batch >= max_writes_per_batch:
            batch.commit()
            batch = db.batch()
            writes_in_batch = 0

        count += 1
        # if count > 1:
        #    break

    # Véglegesítés (last partial batch)
    if writes_in_batch:
        batch.commit()
    print("\nSikeresen feltöltve minden dokumentum a Firestore-ba!")


if __name__ == "__main__":
    upload_zips()
