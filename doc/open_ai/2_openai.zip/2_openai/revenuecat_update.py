# this script will update the products in the RevenueCat with the products in the Google Play Store
# It must create the product, which is a Google Play Store product
# It must add it to the existing entitlement
# It must create the package inside the already existing  offering

from __future__ import annotations

import os
import sys

import requests
from dotenv import load_dotenv

load_dotenv(override=True)

# KONFIGURÁCIÓ
API_KEY = os.environ.get("REVENUECAT_API_KEY", "").strip()

PROJECT_ID = "proj5ae3eb25"  # A te projekt ID-d
# Az API path-ba a RevenueCat resource ID kell (pl. ent… / ofrng…).
# Ha inkább a Dashboard-on látott Identifier / név van megadva, a script listáz és feloldja.
ENTITLEMENT_REF = "LanguageRally"
OFFERING_REF = "LanguageRally"
APP_ID = "appbd95b65dfa"  # Az App ID a RevenueCat-en belül
LOCAL_ZIP_FOLDER = "./firebase/zips"

BASE = "https://api.revenuecat.com/v2"

def product_id_from_zip_filename(filename: str) -> str:
    stem = os.path.splitext(os.path.basename(filename))[0]
    return stem.strip().lower().replace(" ", "_")


def collect_product_ids_from_local_zips(folder: str) -> list[str]:
    if not os.path.isdir(folder):
        die(f"LOCAL_ZIP_FOLDER does not exist or is not a directory: {folder!r}")
    out: list[str] = []
    for name in os.listdir(folder):
        if not name.lower().endswith(".zip"):
            continue
        product_id = product_id_from_zip_filename(name)
        if product_id:
            out.append(product_id)
    return sorted(set(out))


def die(msg: str, resp: requests.Response | None = None) -> None:
    print(msg, file=sys.stderr)
    if resp is not None:
        print(f"HTTP {resp.status_code}: {resp.text}", file=sys.stderr)
    raise SystemExit(1)


def _collect_paged_items(
    headers: dict[str, str],
    *,
    first_url: str,
    first_params: dict[str, str | int] | None = None,
) -> list[dict]:
    """Follow RevenueCat list pagination via next_page (absolute path /v2/...)."""
    items: list[dict] = []
    next_path: str | None = None
    while True:
        if next_path:
            r = requests.get(
                f"https://api.revenuecat.com{next_path}",
                headers=headers,
                timeout=60,
            )
        else:
            r = requests.get(
                first_url,
                headers=headers,
                params=first_params or {},
                timeout=60,
            )
        if r.status_code != 200:
            die("Paged list request failed", r)
        payload = r.json()
        items.extend(payload.get("items") or [])
        next_path = payload.get("next_page")
        if not next_path:
            break
    return items


def resolve_entitlement_id(headers: dict[str, str], ref: str) -> str:
    ref_norm = ref.strip()
    url = f"{BASE}/projects/{PROJECT_ID}/entitlements"
    rows = _collect_paged_items(headers, first_url=url, first_params={"limit": 100})
    for row in rows:
        if row.get("id") == ref_norm:
            return ref_norm
    ref_lower = ref_norm.lower()
    candidates: list[str] = []
    for row in rows:
        rid = row.get("id")
        if not rid:
            continue
        lk = str(row.get("lookup_key") or "")
        dn = str(row.get("display_name") or "")
        if (
            lk == ref_norm
            or dn == ref_norm
            or lk.lower() == ref_lower
            or dn.lower() == ref_lower
        ):
            candidates.append(str(rid))
    uniq = list(dict.fromkeys(candidates))
    if len(uniq) == 1:
        return uniq[0]
    if len(uniq) > 1:
        die(f"Ambiguous entitlement ref {ref_norm!r}; matched ids: {uniq}")
    die(
        f"No entitlement matching {ref_norm!r}. "
        "RevenueCat Dashboard → Project → Entitlements → copy Resource ID (ent…)."
    )


def resolve_offering_id(headers: dict[str, str], ref: str) -> str:
    ref_norm = ref.strip()
    url = f"{BASE}/projects/{PROJECT_ID}/offerings"
    rows = _collect_paged_items(headers, first_url=url, first_params={"limit": 100})
    for row in rows:
        if row.get("id") == ref_norm:
            return ref_norm
    ref_lower = ref_norm.lower()
    candidates: list[str] = []
    for row in rows:
        rid = row.get("id")
        if not rid:
            continue
        lk = str(row.get("lookup_key") or "")
        dn = str(row.get("display_name") or "")
        if (
            lk == ref_norm
            or dn == ref_norm
            or lk.lower() == ref_lower
            or dn.lower() == ref_lower
        ):
            candidates.append(str(rid))
    uniq = list(dict.fromkeys(candidates))
    if len(uniq) == 1:
        return uniq[0]
    if len(uniq) > 1:
        die(f"Ambiguous offering ref {ref_norm!r}; matched ids: {uniq}")
    die(
        f"No offering matching {ref_norm!r}. "
        "RevenueCat Dashboard → Offerings → copy Resource ID (ofrng…)."
    )


def ensure_headers() -> dict[str, str]:
    if not API_KEY:
        die(
            "Missing REVENUECAT_API_KEY. Export your RevenueCat secret API key "
            "(Project settings → API keys → Secret API key)."
        )
    return {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }


def _find_product_id_by_store_sku(
    headers: dict[str, str], store_identifier: str
) -> str | None:
    """Paginate GET /projects/{id}/products until we find this app's SKU."""
    next_path: str | None = None
    while True:
        if next_path:
            lr = requests.get(
                f"https://api.revenuecat.com{next_path}",
                headers=headers,
                timeout=60,
            )
        else:
            lr = requests.get(
                f"{BASE}/projects/{PROJECT_ID}/products",
                headers=headers,
                params={"limit": 100},
                timeout=60,
            )
        if lr.status_code != 200:
            die("List products failed while resolving existing product", lr)
        payload = lr.json()
        for item in payload.get("items") or []:
            app_ok = item.get("app_id") == APP_ID
            if not app_ok and isinstance(item.get("app"), dict):
                app_ok = item["app"].get("id") == APP_ID
            if not app_ok:
                continue
            if item.get("store_identifier") == store_identifier and item.get("id"):
                return str(item["id"])
        next_path = payload.get("next_page")
        if not next_path:
            return None


def ensure_revenuecat_product(headers: dict[str, str], store_identifier: str) -> str:
    """Return RevenueCat internal product id (prod...) for this Play SKU."""
    # Official v2 path: POST /projects/{project_id}/products (not .../apps/.../products).
    url = f"{BASE}/projects/{PROJECT_ID}/products"
    body = {
        "store_identifier": store_identifier,
        "app_id": APP_ID,
        "type": "one_time",
        "display_name": store_identifier,
    }
    r = requests.post(url, json=body, headers=headers, timeout=60)
    if r.status_code == 201:
        data = r.json()
        pid = data.get("id")
        if not pid:
            die("Create product: missing id in response", r)
        return str(pid)
    if r.status_code == 409:
        pid = _find_product_id_by_store_sku(headers, store_identifier)
        if pid:
            return pid
        die(
            f"Create product returned 409 but could not find store_identifier={store_identifier!r} "
            f"for app_id={APP_ID}.",
            r,
        )
    die("Create product failed", r)


def ensure_product_active(headers: dict[str, str], product_id: str) -> None:
    """
    Attach endpoints require an active product. New or archived products can be inactive.
    Try unarchive, then sync from store (Play) if still inactive.
    """
    info_url = f"{BASE}/projects/{PROJECT_ID}/products/{product_id}"

    def fetch_product() -> dict:
        r = requests.get(info_url, headers=headers, timeout=60)
        if r.status_code != 200:
            die("Get product failed", r)
        return r.json()

    data = fetch_product()
    if data.get("state") == "active":
        return

    unarchive_url = (
        f"{BASE}/projects/{PROJECT_ID}/products/{product_id}/actions/unarchive"
    )
    ur = requests.post(unarchive_url, headers=headers, json={}, timeout=60)
    if ur.status_code in (200, 201):
        print(f"Product {product_id}: unarchived → active.")
    elif ur.status_code == 404:
        pass
    else:
        die("Unarchive product failed", ur)

    data = fetch_product()
    if data.get("state") == "active":
        return

    store_url = (
        f"{BASE}/projects/{PROJECT_ID}/products/{product_id}/create_in_store"
    )
    sr = requests.post(store_url, headers=headers, json={}, timeout=60)
    if sr.status_code in (200, 201):
        print(f"Product {product_id}: create_in_store requested.")
    elif sr.status_code == 404:
        die(
            "Product is inactive and create_in_store endpoint was not found (404). "
            "Check RevenueCat API version / docs.",
            sr,
        )
    else:
        die(
            "Product still inactive; create_in_store failed. "
            "Ensure the SKU exists and is active in Google Play and service credentials are linked.",
            sr,
        )

    data = fetch_product()
    if data.get("state") != "active":
        die(
            f"Product {product_id} is still not active (state={data.get('state')!r}). "
            "Open RevenueCat → Product catalog → this product and fix status, then retry.",
            None,
        )


def attach_to_entitlement(
    headers: dict[str, str],
    revenuecat_product_id: str,
    entitlement_resource_id: str,
) -> None:
    url = f"{BASE}/projects/{PROJECT_ID}/entitlements/{entitlement_resource_id}/actions/attach_products"
    r = requests.post(
        url,
        json={"product_ids": [revenuecat_product_id]},
        headers=headers,
        timeout=60,
    )
    if r.status_code not in (200, 409):
        die("Attach products to entitlement failed", r)


def create_package_and_attach(
    headers: dict[str, str],
    revenuecat_product_id: str,
    *,
    offering_resource_id: str,
    lookup_key: str,
    display_name: str,
) -> None:
    # https://www.revenuecat.com/docs/api-v2 — Create package requires lookup_key + display_name
    pkg_create_url = (
        f"{BASE}/projects/{PROJECT_ID}/offerings/{offering_resource_id}/packages"
    )
    create_body = {
        "lookup_key": lookup_key[:200],
        "display_name": display_name[:1500],
    }
    r = requests.post(pkg_create_url, json=create_body, headers=headers, timeout=60)
    if r.status_code == 409:
        # Package lookup_key already exists — fetch packages on offering and find id
        list_url = (
            f"{BASE}/projects/{PROJECT_ID}/offerings/{offering_resource_id}/packages"
        )
        lr = requests.get(list_url, headers=headers, timeout=60)
        if lr.status_code != 200:
            die("Create package conflict (409) but could not list packages", lr)
        package_id = None
        for item in lr.json().get("items") or []:
            if item.get("lookup_key") == lookup_key[:200]:
                package_id = item.get("id")
                break
        if not package_id:
            die(f"No package with lookup_key={lookup_key!r} after 409.", lr)
    elif r.status_code != 201:
        die("Create package failed", r)
    else:
        package_id = r.json().get("id")
        if not package_id:
            die("Create package: missing id in response", r)

    attach_url = (
        f"{BASE}/projects/{PROJECT_ID}/packages/{package_id}/actions/attach_products"
    )
    attach_body = {
        "products": [
            {
                "product_id": revenuecat_product_id,
                "eligibility_criteria": "all",
            }
        ]
    }
    ar = requests.post(attach_url, json=attach_body, headers=headers, timeout=60)
    if ar.status_code != 200:
        die("Attach products to package failed", ar)


def run_import() -> None:
    headers = ensure_headers()
    entitlement_id = resolve_entitlement_id(headers, ENTITLEMENT_REF)
    offering_id = resolve_offering_id(headers, OFFERING_REF)
    print(f"Entitlement resource id: {entitlement_id}")
    print(f"Offering resource id: {offering_id}")

    product_ids = collect_product_ids_from_local_zips(LOCAL_ZIP_FOLDER)
    if not product_ids:
        die(f"No .zip files found in LOCAL_ZIP_FOLDER: {LOCAL_ZIP_FOLDER!r}")

    for p_id in product_ids:
        print(f"--- Dolgozom ezen: {p_id} ---")

        rc_product_id = ensure_revenuecat_product(headers, p_id)
        print(f"RevenueCat product id: {rc_product_id}")

        ensure_product_active(headers, rc_product_id)

        attach_to_entitlement(headers, rc_product_id, entitlement_id)

        # Package lookup_key: SDK-facing identifier (Play SKU is fine if ≤200 chars)
        create_package_and_attach(
            headers,
            rc_product_id,
            offering_resource_id=offering_id,
            lookup_key=p_id,
            display_name=p_id.replace("_", " "),
        )
        print(f"Siker: {p_id} — entitlement + offering package kész.")


if __name__ == "__main__":
    run_import()
