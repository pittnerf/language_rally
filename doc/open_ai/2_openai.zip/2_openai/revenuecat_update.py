# Sync RevenueCat products with zip files in LOCAL_ZIP_FOLDER.
# - Removes products from the entitlement + offering when no matching local zip exists.
# - Creates missing products, attaches them to the entitlement, and adds offering packages.

from __future__ import annotations

import argparse
import os
import random
import sys
import time

import requests
from dotenv import load_dotenv

load_dotenv(override=True)

# KONFIGURÁCIÓ
API_KEY = os.environ.get("REVENUECAT_API_KEY", "").strip()

PROJECT_ID = "proj5ae3eb25"  # A te projekt ID-d
# Az API path-ba a RevenueCat resource ID kell (pl. ent… / ofrng…).
# Ha inkább a Dashboard-on látott Identifier / név van megadva, a script listáz és feloldja.
ENTITLEMENT_REF = "LanguageRally"
OFFERING_REF = "LanguageRally"
APP_ID = "appbd95b65dfa"  # Az App ID a RevenueCat-en belül
LOCAL_ZIP_FOLDER = "./firebase/zips"

BASE = "https://api.revenuecat.com/v2"

# RevenueCat rate limits aggressively; space requests and retry 429s using backoff_ms.
MAX_RATE_LIMIT_RETRIES = 15
MIN_REQUEST_INTERVAL_SEC = 0.5
PRODUCT_INTERVAL_SEC = 1.0
PRODUCT_PROPAGATION_RETRIES = 12
PRODUCT_PROPAGATION_WAIT_SEC = 2.0
_last_request_at = 0.0


def _parse_rate_limit_wait(resp: requests.Response, attempt: int) -> float:
    try:
        data = resp.json()
        backoff_ms = data.get("backoff_ms")
        if backoff_ms is not None:
            return max(float(backoff_ms) / 1000.0, 0.5)
    except Exception:
        pass
    return min(2.0**attempt, 60.0)


def rc_request(method: str, url: str, **kwargs) -> requests.Response:
    global _last_request_at

    headers = kwargs.pop("headers", None)
    timeout = kwargs.pop("timeout", 60)
    last_resp: requests.Response | None = None

    for attempt in range(MAX_RATE_LIMIT_RETRIES):
        elapsed = time.monotonic() - _last_request_at
        if elapsed < MIN_REQUEST_INTERVAL_SEC:
            time.sleep(MIN_REQUEST_INTERVAL_SEC - elapsed)

        resp = requests.request(
            method,
            url,
            headers=headers,
            timeout=timeout,
            **kwargs,
        )
        _last_request_at = time.monotonic()
        last_resp = resp

        if resp.status_code != 429:
            return resp

        wait = _parse_rate_limit_wait(resp, attempt)
        wait += random.uniform(0, min(wait * 0.1, 2.0))
        print(
            f"Rate limited (429) on {method} {url}; "
            f"waiting {wait:.1f}s (retry {attempt + 1}/{MAX_RATE_LIMIT_RETRIES})...",
            file=sys.stderr,
        )
        time.sleep(wait)

    if last_resp is None:
        die(f"Request failed before sending: {method} {url}")
    return last_resp


def rc_get(url: str, **kwargs) -> requests.Response:
    return rc_request("GET", url, **kwargs)


def rc_post(url: str, **kwargs) -> requests.Response:
    return rc_request("POST", url, **kwargs)


def rc_delete(url: str, **kwargs) -> requests.Response:
    return rc_request("DELETE", url, **kwargs)


def product_id_from_zip_filename(filename: str) -> str:
    stem = os.path.splitext(os.path.basename(filename))[0]
    return stem.strip().lower().replace(" ", "_")


def collect_product_ids_from_local_zips(folder: str) -> set[str]:
    if not os.path.isdir(folder):
        die(f"LOCAL_ZIP_FOLDER does not exist or is not a directory: {folder!r}")
    out: set[str] = set()
    for name in os.listdir(folder):
        if not name.lower().endswith(".zip"):
            continue
        product_id = product_id_from_zip_filename(name)
        if product_id:
            out.add(product_id)
    return out


def _product_belongs_to_app(product: dict) -> bool:
    if product.get("app_id") == APP_ID:
        return True
    app = product.get("app")
    return isinstance(app, dict) and app.get("id") == APP_ID


def die(msg: str, resp: requests.Response | None = None) -> None:
    print(msg, file=sys.stderr)
    if resp is not None:
        print(f"HTTP {resp.status_code}: {resp.text}", file=sys.stderr)
    raise SystemExit(1)


def _next_page_url(next_page: str | None) -> str | None:
    if not next_page:
        return None
    if next_page.startswith("http://") or next_page.startswith("https://"):
        return next_page
    if next_page.startswith("/"):
        return f"https://api.revenuecat.com{next_page}"
    return f"https://api.revenuecat.com/{next_page}"


def _collect_paged_items(
    headers: dict[str, str],
    *,
    first_url: str,
    first_params: dict[str, str | int] | None = None,
) -> list[dict]:
    """Follow RevenueCat list pagination via next_page."""
    items: list[dict] = []
    next_url: str | None = None
    while True:
        if next_url:
            r = rc_get(next_url, headers=headers, timeout=60)
        else:
            r = rc_get(
                first_url,
                headers=headers,
                params=first_params or {},
                timeout=60,
            )
        if r.status_code != 200:
            die("Paged list request failed", r)
        payload = r.json()
        items.extend(payload.get("items") or [])
        next_url = _next_page_url(payload.get("next_page"))
        if not next_url:
            break
    return items


def resolve_entitlement_id(headers: dict[str, str], ref: str) -> str:
    ref_norm = ref.strip()
    url = f"{BASE}/projects/{PROJECT_ID}/entitlements"
    rows = _collect_paged_items(headers, first_url=url, first_params={"limit": 100})
    for row in rows:
        if row.get("id") == ref_norm:
            return ref_norm
    ref_lower = ref_norm.lower()
    candidates: list[str] = []
    for row in rows:
        rid = row.get("id")
        if not rid:
            continue
        lk = str(row.get("lookup_key") or "")
        dn = str(row.get("display_name") or "")
        if (
            lk == ref_norm
            or dn == ref_norm
            or lk.lower() == ref_lower
            or dn.lower() == ref_lower
        ):
            candidates.append(str(rid))
    uniq = list(dict.fromkeys(candidates))
    if len(uniq) == 1:
        return uniq[0]
    if len(uniq) > 1:
        die(f"Ambiguous entitlement ref {ref_norm!r}; matched ids: {uniq}")
    die(
        f"No entitlement matching {ref_norm!r}. "
        "RevenueCat Dashboard → Project → Entitlements → copy Resource ID (ent…)."
    )


def resolve_offering_id(headers: dict[str, str], ref: str) -> str:
    ref_norm = ref.strip()
    url = f"{BASE}/projects/{PROJECT_ID}/offerings"
    rows = _collect_paged_items(headers, first_url=url, first_params={"limit": 100})
    for row in rows:
        if row.get("id") == ref_norm:
            return ref_norm
    ref_lower = ref_norm.lower()
    candidates: list[str] = []
    for row in rows:
        rid = row.get("id")
        if not rid:
            continue
        lk = str(row.get("lookup_key") or "")
        dn = str(row.get("display_name") or "")
        if (
            lk == ref_norm
            or dn == ref_norm
            or lk.lower() == ref_lower
            or dn.lower() == ref_lower
        ):
            candidates.append(str(rid))
    uniq = list(dict.fromkeys(candidates))
    if len(uniq) == 1:
        return uniq[0]
    if len(uniq) > 1:
        die(f"Ambiguous offering ref {ref_norm!r}; matched ids: {uniq}")
    die(
        f"No offering matching {ref_norm!r}. "
        "RevenueCat Dashboard → Offerings → copy Resource ID (ofrng…)."
    )


def ensure_headers() -> dict[str, str]:
    if not API_KEY:
        die(
            "Missing REVENUECAT_API_KEY. Export your RevenueCat secret API key "
            "(Project settings → API keys → Secret API key)."
        )
    return {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }


def _find_product_id_by_store_sku(
    headers: dict[str, str], store_identifier: str
) -> str | None:
    """Paginate GET /projects/{id}/products until we find this app's SKU."""
    url = f"{BASE}/projects/{PROJECT_ID}/products"
    for item in _collect_paged_items(headers, first_url=url, first_params={"limit": 100}):
        app_ok = item.get("app_id") == APP_ID
        if not app_ok and isinstance(item.get("app"), dict):
            app_ok = item["app"].get("id") == APP_ID
        if not app_ok:
            continue
        if item.get("store_identifier") == store_identifier and item.get("id"):
            return str(item["id"])
    return None


def ensure_revenuecat_product(headers: dict[str, str], store_identifier: str) -> str:
    """Return RevenueCat internal product id (prod...) for this Play SKU."""
    # Official v2 path: POST /projects/{project_id}/products (not .../apps/.../products).
    url = f"{BASE}/projects/{PROJECT_ID}/products"
    body = {
        "store_identifier": store_identifier,
        "app_id": APP_ID,
        "type": "one_time",
        "display_name": store_identifier,
    }
    r = rc_post(url, json=body, headers=headers, timeout=60)
    if r.status_code == 201:
        data = r.json()
        pid = data.get("id")
        if not pid:
            die("Create product: missing id in response", r)
        return str(pid)
    if r.status_code == 409:
        pid = _find_product_id_by_store_sku(headers, store_identifier)
        if pid:
            return pid
        die(
            f"Create product returned 409 but could not find store_identifier={store_identifier!r} "
            f"for app_id={APP_ID}.",
            r,
        )
    die("Create product failed", r)


def fetch_product(
    headers: dict[str, str],
    product_id: str,
    *,
    store_identifier: str | None = None,
) -> dict:
    resolved_id = product_id
    last_resp: requests.Response | None = None

    for attempt in range(PRODUCT_PROPAGATION_RETRIES):
        url = f"{BASE}/projects/{PROJECT_ID}/products/{resolved_id}"
        r = rc_get(url, headers=headers, timeout=60)
        if r.status_code == 200:
            return r.json()
        if r.status_code != 404:
            die("Get product failed", r)

        last_resp = r
        if attempt < PRODUCT_PROPAGATION_RETRIES - 1:
            wait = PRODUCT_PROPAGATION_WAIT_SEC * (attempt + 1)
            print(
                f"Product {resolved_id} not found yet (404), "
                f"retrying in {wait:.1f}s ({attempt + 1}/{PRODUCT_PROPAGATION_RETRIES})...",
                file=sys.stderr,
            )
            time.sleep(wait)

    if store_identifier:
        alt_id = _find_product_id_by_store_sku(headers, store_identifier)
        if alt_id and alt_id != resolved_id:
            resolved_id = alt_id
            print(f"Re-resolved product by SKU {store_identifier!r}: {resolved_id}")
            r = rc_get(
                f"{BASE}/projects/{PROJECT_ID}/products/{resolved_id}",
                headers=headers,
                timeout=60,
            )
            if r.status_code == 200:
                return r.json()
            last_resp = r

    die("Get product failed", last_resp)


def ensure_product_active(
    headers: dict[str, str],
    product_id: str,
    *,
    store_identifier: str | None = None,
) -> str:
    """
    Attach endpoints require an active product. New or archived products can be inactive.
    Try unarchive, then sync from store (Play) if still inactive.
    Returns the canonical RevenueCat product id.
    """
    data = fetch_product(
        headers, product_id, store_identifier=store_identifier
    )
    product_id = str(data.get("id") or product_id)
    if data.get("state") == "active":
        return product_id

    unarchive_url = (
        f"{BASE}/projects/{PROJECT_ID}/products/{product_id}/actions/unarchive"
    )
    ur = rc_post(unarchive_url, headers=headers, json={}, timeout=60)
    if ur.status_code in (200, 201):
        print(f"Product {product_id}: unarchived → active.")
    elif ur.status_code == 404:
        pass
    else:
        die("Unarchive product failed", ur)

    data = fetch_product(
        headers, product_id, store_identifier=store_identifier
    )
    product_id = str(data.get("id") or product_id)
    if data.get("state") == "active":
        return product_id

    store_url = (
        f"{BASE}/projects/{PROJECT_ID}/products/{product_id}/create_in_store"
    )
    sr = rc_post(store_url, headers=headers, json={}, timeout=60)
    if sr.status_code in (200, 201):
        print(f"Product {product_id}: create_in_store requested.")
    elif sr.status_code == 404:
        die(
            "Product is inactive and create_in_store endpoint was not found (404). "
            "Check RevenueCat API version / docs.",
            sr,
        )
    else:
        die(
            "Product still inactive; create_in_store failed. "
            "Ensure the SKU exists and is active in Google Play and service credentials are linked.",
            sr,
        )

    data = fetch_product(
        headers, product_id, store_identifier=store_identifier
    )
    product_id = str(data.get("id") or product_id)
    if data.get("state") != "active":
        die(
            f"Product {product_id} is still not active (state={data.get('state')!r}). "
            "Open RevenueCat → Product catalog → this product and fix status, then retry.",
            None,
        )
    return product_id


def list_entitlement_products(
    headers: dict[str, str], entitlement_resource_id: str
) -> list[dict]:
    url = f"{BASE}/projects/{PROJECT_ID}/entitlements/{entitlement_resource_id}/products"
    return _collect_paged_items(headers, first_url=url, first_params={"limit": 100})


def list_offering_packages(
    headers: dict[str, str], offering_resource_id: str
) -> list[dict]:
    url = f"{BASE}/projects/{PROJECT_ID}/offerings/{offering_resource_id}/packages"
    return _collect_paged_items(headers, first_url=url, first_params={"limit": 100})


def find_package_by_lookup_key(
    headers: dict[str, str], offering_resource_id: str, lookup_key: str
) -> str | None:
    normalized_key = lookup_key[:200]
    for pkg in list_offering_packages(headers, offering_resource_id):
        if pkg.get("lookup_key") == normalized_key and pkg.get("id"):
            return str(pkg["id"])
    return None


def detach_from_entitlement(
    headers: dict[str, str],
    entitlement_resource_id: str,
    revenuecat_product_ids: list[str],
) -> None:
    if not revenuecat_product_ids:
        return
    url = (
        f"{BASE}/projects/{PROJECT_ID}/entitlements/"
        f"{entitlement_resource_id}/actions/detach_products"
    )
    r = rc_post(
        url,
        json={"product_ids": revenuecat_product_ids},
        headers=headers,
        timeout=60,
    )
    if r.status_code not in (200, 404):
        die("Detach products from entitlement failed", r)


def delete_package(headers: dict[str, str], package_id: str) -> None:
    url = f"{BASE}/projects/{PROJECT_ID}/packages/{package_id}"
    r = rc_delete(url, headers=headers, timeout=60)
    if r.status_code not in (200, 204, 404):
        die("Delete package failed", r)


def _is_revenuecat_system_sku(store_identifier: str) -> bool:
    return store_identifier.startswith("$")


def archive_product(headers: dict[str, str], product_id: str) -> bool:
    url = f"{BASE}/projects/{PROJECT_ID}/products/{product_id}/actions/archive"
    r = rc_post(url, headers=headers, json={}, timeout=60)
    return r.status_code in (200, 201, 404)


def remove_product_from_catalog(
    headers: dict[str, str], product_id: str, store_identifier: str
) -> str:
    """
    Remove a product from the active catalog.
    Returns: 'deleted', 'archived', or 'skipped'.
    """
    if _is_revenuecat_system_sku(store_identifier):
        print(f"Skipping RevenueCat system product: {store_identifier}")
        return "skipped"

    url = f"{BASE}/projects/{PROJECT_ID}/products/{product_id}"
    r = rc_delete(url, headers=headers, timeout=60)
    if r.status_code in (200, 204, 404):
        return "deleted"

    if r.status_code == 422:
        try:
            message = (r.json().get("message") or "").lower()
        except Exception:
            message = ""
        if "transaction" in message or "unprocessable" in message:
            if archive_product(headers, product_id):
                return "archived"
        print(
            f"Could not delete {store_identifier} ({product_id}): {r.text}",
            file=sys.stderr,
        )
        return "skipped"

    die(f"Delete product failed for {store_identifier}", r)


def sync_removals(
    headers: dict[str, str],
    entitlement_id: str,
    offering_id: str,
    local_ids: set[str],
    *,
    dry_run: bool,
) -> None:
    entitlement_products = list_entitlement_products(headers, entitlement_id)
    packages = list_offering_packages(headers, offering_id)

    packages_by_lookup: dict[str, dict] = {}
    for pkg in packages:
        lookup_key = str(pkg.get("lookup_key") or "").strip().lower()
        if lookup_key:
            packages_by_lookup[lookup_key] = pkg

    to_remove: set[str] = set()
    for product in entitlement_products:
        if not _product_belongs_to_app(product):
            continue
        store_id = str(product.get("store_identifier") or "").strip().lower()
        if (
            store_id
            and store_id not in local_ids
            and not _is_revenuecat_system_sku(store_id)
        ):
            to_remove.add(store_id)

    for pkg in packages:
        lookup_key = str(pkg.get("lookup_key") or "").strip().lower()
        if (
            lookup_key
            and lookup_key not in local_ids
            and not _is_revenuecat_system_sku(lookup_key)
        ):
            to_remove.add(lookup_key)

    if not to_remove:
        print("No entitlement/offering products to remove.")
        return

    print(f"Removing {len(to_remove)} product(s) not present in {LOCAL_ZIP_FOLDER!r}:")
    for store_id in sorted(to_remove):
        print(f"  - {store_id}")

    if dry_run:
        print("(dry run — no removals applied)")
        return

    rc_product_ids = [
        str(product["id"])
        for product in entitlement_products
        if _product_belongs_to_app(product)
        and str(product.get("store_identifier") or "").strip().lower() in to_remove
        and product.get("id")
    ]
    detach_from_entitlement(headers, entitlement_id, rc_product_ids)
    if rc_product_ids:
        print(f"Detached {len(rc_product_ids)} product(s) from entitlement.")

    deleted_packages = 0
    for store_id in sorted(to_remove):
        pkg = packages_by_lookup.get(store_id)
        if not pkg or not pkg.get("id"):
            continue
        delete_package(headers, str(pkg["id"]))
        deleted_packages += 1
    if deleted_packages:
        print(f"Deleted {deleted_packages} package(s) from offering.")

    deleted_products = 0
    archived_products = 0
    skipped_products = 0
    for store_id in sorted(to_remove):
        rc_product_id = _find_product_id_by_store_sku(headers, store_id)
        if not rc_product_id:
            continue
        outcome = remove_product_from_catalog(headers, rc_product_id, store_id)
        if outcome == "deleted":
            deleted_products += 1
        elif outcome == "archived":
            archived_products += 1
            print(f"Archived product (has transactions): {store_id}")
        else:
            skipped_products += 1
    if deleted_products:
        print(f"Deleted {deleted_products} product(s) from RevenueCat catalog.")
    if archived_products:
        print(f"Archived {archived_products} product(s) that could not be deleted.")
    if skipped_products:
        print(f"Skipped {skipped_products} product(s) in RevenueCat catalog.")


def list_package_products(headers: dict[str, str], package_id: str) -> list[dict]:
    url = f"{BASE}/projects/{PROJECT_ID}/packages/{package_id}/products"
    return _collect_paged_items(headers, first_url=url, first_params={"limit": 100})


def _package_product_id(item: dict) -> str | None:
    if item.get("product_id"):
        return str(item["product_id"])
    product = item.get("product")
    if isinstance(product, dict) and product.get("id"):
        return str(product["id"])
    return None


def detach_from_package(
    headers: dict[str, str], package_id: str, revenuecat_product_ids: list[str]
) -> None:
    if not revenuecat_product_ids:
        return
    url = (
        f"{BASE}/projects/{PROJECT_ID}/packages/{package_id}/actions/detach_products"
    )
    r = rc_post(
        url,
        json={"product_ids": revenuecat_product_ids},
        headers=headers,
        timeout=60,
    )
    if r.status_code not in (200, 404):
        die("Detach products from package failed", r)


def ensure_package_has_product(
    headers: dict[str, str], package_id: str, revenuecat_product_id: str
) -> None:
    attached_items = list_package_products(headers, package_id)
    attached_ids = [
        pid
        for pid in (_package_product_id(item) for item in attached_items)
        if pid
    ]

    if revenuecat_product_id in attached_ids:
        return

    to_detach = [pid for pid in attached_ids if pid != revenuecat_product_id]
    if to_detach:
        detach_from_package(headers, package_id, to_detach)

    attach_url = (
        f"{BASE}/projects/{PROJECT_ID}/packages/{package_id}/actions/attach_products"
    )
    attach_body = {
        "products": [
            {
                "product_id": revenuecat_product_id,
                "eligibility_criteria": "all",
            }
        ]
    }
    ar = rc_post(attach_url, json=attach_body, headers=headers, timeout=60)
    if ar.status_code == 200:
        return

    if ar.status_code == 422:
        attached_items = list_package_products(headers, package_id)
        attached_ids = [
            pid
            for pid in (_package_product_id(item) for item in attached_items)
            if pid
        ]
        if attached_ids:
            detach_from_package(headers, package_id, attached_ids)
        ar = rc_post(attach_url, json=attach_body, headers=headers, timeout=60)

    if ar.status_code != 200:
        die("Attach products to package failed", ar)


def attach_to_entitlement(
    headers: dict[str, str],
    revenuecat_product_id: str,
    entitlement_resource_id: str,
) -> None:
    url = f"{BASE}/projects/{PROJECT_ID}/entitlements/{entitlement_resource_id}/actions/attach_products"
    r = rc_post(
        url,
        json={"product_ids": [revenuecat_product_id]},
        headers=headers,
        timeout=60,
    )
    if r.status_code not in (200, 409):
        die("Attach products to entitlement failed", r)


def create_package_and_attach(
    headers: dict[str, str],
    revenuecat_product_id: str,
    *,
    offering_resource_id: str,
    lookup_key: str,
    display_name: str,
) -> None:
    # https://www.revenuecat.com/docs/api-v2 — Create package requires lookup_key + display_name
    pkg_create_url = (
        f"{BASE}/projects/{PROJECT_ID}/offerings/{offering_resource_id}/packages"
    )
    create_body = {
        "lookup_key": lookup_key[:200],
        "display_name": display_name[:1500],
    }
    r = rc_post(pkg_create_url, json=create_body, headers=headers, timeout=60)
    if r.status_code == 409:
        # Package lookup_key already exists — paginate all offering packages to find it.
        package_id = find_package_by_lookup_key(
            headers, offering_resource_id, lookup_key
        )
        if not package_id:
            die(f"No package with lookup_key={lookup_key!r} after 409.", r)
    elif r.status_code != 201:
        die("Create package failed", r)
    else:
        package_id = r.json().get("id")
        if not package_id:
            die("Create package: missing id in response", r)

    ensure_package_has_product(headers, str(package_id), revenuecat_product_id)


def run_import(*, dry_run: bool = False) -> None:
    headers = ensure_headers()
    entitlement_id = resolve_entitlement_id(headers, ENTITLEMENT_REF)
    offering_id = resolve_offering_id(headers, OFFERING_REF)
    print(f"Entitlement resource id: {entitlement_id}")
    print(f"Offering resource id: {offering_id}")

    local_ids = collect_product_ids_from_local_zips(LOCAL_ZIP_FOLDER)
    if not local_ids:
        die(f"No .zip files found in LOCAL_ZIP_FOLDER: {LOCAL_ZIP_FOLDER!r}")

    print(f"Local zip products: {len(local_ids)}")
    print()
    sync_removals(
        headers,
        entitlement_id,
        offering_id,
        local_ids,
        dry_run=dry_run,
    )
    print()

    for p_id in sorted(local_ids):
        print(f"--- {'Would ensure' if dry_run else 'Processing'}: {p_id} ---")
        if dry_run:
            continue

        rc_product_id = ensure_revenuecat_product(headers, p_id)
        print(f"RevenueCat product id: {rc_product_id}")

        rc_product_id = ensure_product_active(
            headers, rc_product_id, store_identifier=p_id
        )

        attach_to_entitlement(headers, rc_product_id, entitlement_id)

        # Package lookup_key: SDK-facing identifier (Play SKU is fine if ≤200 chars)
        create_package_and_attach(
            headers,
            rc_product_id,
            offering_resource_id=offering_id,
            lookup_key=p_id,
            display_name=p_id.replace("_", " "),
        )
        print(f"Done: {p_id} — entitlement + offering package ready.")
        time.sleep(PRODUCT_INTERVAL_SEC)

    if dry_run:
        print(f"\nDry run complete. Would ensure {len(local_ids)} local product(s).")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Sync RevenueCat entitlement and offering with LOCAL_ZIP_FOLDER."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show planned removals and creates without changing RevenueCat.",
    )
    args = parser.parse_args()
    run_import(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
