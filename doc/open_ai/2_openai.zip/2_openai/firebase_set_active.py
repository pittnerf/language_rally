# Set isActive=True for all documents in the store_products Firestore collection.
# collection name: store_products
# database name: languagerally

import argparse

import firebase_admin
from firebase_admin import credentials
from google.cloud import firestore

service_account_path = "firebase/languagerally-firebase-adminsdk-fbsvc-06bd60e242.json"
expected_project_id = "languagerally"
firestore_database_id = "languagerally"
collection_name = "store_products"
max_writes_per_batch = 450


def get_db() -> firestore.Client:
    cred = credentials.Certificate(service_account_path)
    firebase_admin.initialize_app(cred)

    actual_project_id = getattr(cred, "project_id", None)
    if actual_project_id != expected_project_id:
        raise RuntimeError(
            "Service account project_id mismatch. "
            f"Expected '{expected_project_id}', got '{actual_project_id}'. "
            f"Check: {service_account_path}"
        )

    return firestore.Client(
        project=expected_project_id,
        credentials=cred.get_credential(),
        database=firestore_database_id,
    )


def set_all_active(*, dry_run: bool = False) -> None:
    db = get_db()
    docs = list(db.collection(collection_name).stream())
    print(f"Found {len(docs)} document(s) in '{collection_name}'.")

    batch = db.batch()
    writes_in_batch = 0
    updated = 0
    already_active = 0

    for doc in docs:
        data = doc.to_dict() or {}
        if data.get("isActive") is True:
            already_active += 1
            continue

        print(f"{'Would update' if dry_run else 'Updating'}: {doc.id}")
        if not dry_run:
            batch.update(doc.reference, {"isActive": True})
            writes_in_batch += 1
            if writes_in_batch >= max_writes_per_batch:
                batch.commit()
                batch = db.batch()
                writes_in_batch = 0
        updated += 1

    if not dry_run and writes_in_batch:
        batch.commit()

    action = "Would update" if dry_run else "Updated"
    print(
        f"\n{action} {updated} document(s). "
        f"{already_active} already had isActive=True."
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Set isActive=True for all store_products documents."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List documents that would be updated without writing changes.",
    )
    args = parser.parse_args()
    set_all_active(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
