# this script counts the number of characters to translate
# it will take all json files from the translate_from/words and /expressions folders
# will read all the itesm from the json files
# will count:
# - the length of the "source_expression", for example "source_expression": "This is a dog", so the length is 13 characters
# - the length of "source" from the list of "examples": [    {        "source": "This is a dog.",      "target": "Das ist ein Hund."       }     ],
# - will collect all unqie categories from the  list of "categories": [ { "category_name": "Pets"     }, so "Pets" and at the end of the file will counth their lengths, too
# At the end of each file, it has to display the file name, thetotal number of characters to translate (source_expression + source from examples, and the total lenght of the categories)
# as well as the grand total of all files.

import json
import os

BASE_DIR = os.path.join(os.path.dirname(__file__), "translate_from")
SUBFOLDERS = ["words", "expressions"]


def count_file(path: str) -> tuple[int, int, set[str]]:
    """Return (source_expression_chars, example_source_chars, unique_categories)."""
    with open(path, encoding="utf-8") as f:
        items = json.load(f)

    expr_chars = 0
    example_chars = 0
    categories: set[str] = set()

    for item in items:
        expr_chars += len(item.get("source_expression", ""))
        for ex in item.get("examples", []):
            example_chars += len(ex.get("source", ""))
        for cat in item.get("categories", []):
            name = cat.get("category_name", "")
            if name:
                categories.add(name)

    return expr_chars, example_chars, categories


def main() -> None:
    grand_expr = 0
    grand_examples = 0
    all_categories: set[str] = set()

    for subfolder in SUBFOLDERS:
        folder = os.path.join(BASE_DIR, subfolder)
        if not os.path.isdir(folder):
            print(f"Folder not found, skipping: {folder}")
            continue

        json_files = sorted(
            f for f in os.listdir(folder) if f.lower().endswith(".json")
        )

        print(f"\n{'═' * 70}")
        print(f"  Folder: translate_from/{subfolder}  ({len(json_files)} files)")
        print(f"{'═' * 70}")

        for filename in json_files:
            path = os.path.join(folder, filename)
            expr_chars, example_chars, categories = count_file(path)
            total = expr_chars + example_chars
            cat_chars = sum(len(c) for c in categories)

            print(f"\n  {filename}")
            print(f"    source_expression chars : {expr_chars:>8,}")
            print(f"    example source chars    : {example_chars:>8,}")
            print(f"    subtotal (to translate) : {total:>8,}")
            print(
                f"    unique categories       : {len(categories):>8,}  ({cat_chars:,} chars)"
            )
            print(f"    categories              : {', '.join(sorted(categories))}")

            grand_expr += expr_chars
            grand_examples += example_chars
            all_categories |= categories

    grand_total = grand_expr + grand_examples
    cat_total_chars = sum(len(c) for c in all_categories)

    print(f"\n{'═' * 70}")
    print("  GRAND TOTAL")
    print(f"{'═' * 70}")
    print(f"  source_expression chars : {grand_expr:>10,}")
    print(f"  example source chars    : {grand_examples:>10,}")
    print(f"  total chars to translate: {grand_total:>10,}")
    print(
        f"  unique categories       : {len(all_categories):>10,}  ({cat_total_chars:,} chars)"
    )
    # print(f"  categories              : {', '.join(sorted(all_categories))}")
    print()


if __name__ == "__main__":
    main()
