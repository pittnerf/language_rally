# Sync Google Play one-time products with zip files in LOCAL_ZIP_FOLDER.
# - Deletes store products that have no matching local zip.
# - Creates store products for local zips that are missing from the store.
import argparse
import json
import os
import sys

from googleapiclient.errors import HttpError

from googleplay_list_products import build_service, list_one_time_products, product_ids
from googleplay_update_info import (
    LOCAL_ZIP_FOLDER,
    PACKAGE_NAME,
    build_description,
    build_title,
    language_name,
    upsert_one_time_product,
)

BATCH_DELETE_SIZE = 100


def local_zip_product_ids() -> set[str]:
    ids: set[str] = set()
    if not os.path.isdir(LOCAL_ZIP_FOLDER):
        raise FileNotFoundError(f"Zip folder not found: {LOCAL_ZIP_FOLDER}")

    for file_name in os.listdir(LOCAL_ZIP_FOLDER):
        if not file_name.endswith(".zip"):
            continue
        raw_name = os.path.splitext(file_name)[0]
        parts = raw_name.split("_")
        if len(parts) < 5:
            print(f"SKIP local zip (unexpected filename format): {file_name}")
            continue
        ids.add(raw_name.lower())
    return ids


def listing_from_zip(file_name: str) -> tuple[str, str, str] | None:
    raw_name = os.path.splitext(file_name)[0]
    parts = raw_name.split("_")
    if len(parts) < 5:
        return None

    product_id = raw_name.lower()
    category = " ".join(parts[4:])
    language_code_1 = parts[1].lower()
    language_code_2 = parts[2].lower()
    language_1 = language_name(language_code_1)
    language_2 = language_name(language_code_2)
    level = parts[3].upper()

    title = build_title(language_1, language_2, level, category)
    description = build_description(language_1, language_2, level, category)
    return product_id, title, description


def delete_products(service, product_ids_to_delete: list[str], *, dry_run: bool) -> None:
    if not product_ids_to_delete:
        return

    for product_id in product_ids_to_delete:
        print(f"{'Would delete' if dry_run else 'Deleting'} from Play Store: {product_id}")

    if dry_run:
        return

    for i in range(0, len(product_ids_to_delete), BATCH_DELETE_SIZE):
        batch = product_ids_to_delete[i : i + BATCH_DELETE_SIZE]
        service.monetization().onetimeproducts().batchDelete(
            packageName=PACKAGE_NAME,
            body={
                "requests": [
                    {
                        "packageName": PACKAGE_NAME,
                        "productId": product_id,
                        "latencyTolerance": "PRODUCT_UPDATE_LATENCY_TOLERANCE_LATENCY_SENSITIVE",
                    }
                    for product_id in batch
                ]
            },
        ).execute()


def create_products(product_ids_to_create: set[str], *, dry_run: bool) -> None:
    if not product_ids_to_create:
        return

    zip_by_product_id: dict[str, str] = {}
    for file_name in os.listdir(LOCAL_ZIP_FOLDER):
        if not file_name.endswith(".zip"):
            continue
        raw_name = os.path.splitext(file_name)[0]
        product_id = raw_name.lower()
        if product_id in product_ids_to_create:
            zip_by_product_id[product_id] = file_name

    for product_id in sorted(product_ids_to_create):
        file_name = zip_by_product_id.get(product_id)
        if not file_name:
            print(f"SKIP create (zip not found): {product_id}")
            continue

        listing = listing_from_zip(file_name)
        if not listing:
            print(f"SKIP create (unexpected filename format): {file_name}")
            continue

        _, title, description = listing
        print(f"{'Would create' if dry_run else 'Creating'} in Play Store: {product_id}")
        if dry_run:
            continue

        try:
            upsert_one_time_product(product_id, title, description)
        except Exception as e:
            print(f"Error creating {product_id}: {e}", file=sys.stderr)


def sync_products(*, dry_run: bool = False) -> None:
    service = build_service()
    store_ids = set(product_ids(list_one_time_products(service)))
    local_ids = local_zip_product_ids()

    to_delete = sorted(store_ids - local_ids)
    to_create = local_ids - store_ids
    in_sync = store_ids & local_ids

    print(f"Package: {PACKAGE_NAME}")
    print(f"Local zip folder: {LOCAL_ZIP_FOLDER}")
    print(f"Store products: {len(store_ids)}")
    print(f"Local zip products: {len(local_ids)}")
    print(f"Already in sync: {len(in_sync)}")
    print(f"To delete from store: {len(to_delete)}")
    print(f"To create in store: {len(to_create)}")
    print()

    delete_products(service, to_delete, dry_run=dry_run)
    if to_delete:
        print()
    create_products(to_create, dry_run=dry_run)

    action = "Would sync" if dry_run else "Synced"
    print(f"\n{action} Play Store products with local zips.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Sync Google Play one-time products with zip files in LOCAL_ZIP_FOLDER."
        )
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show planned deletes/creates without changing the Play Store.",
    )
    args = parser.parse_args()

    try:
        sync_products(dry_run=args.dry_run)
    except HttpError as e:
        try:
            payload = json.loads((e.content or b"{}").decode("utf-8"))
            message = (payload.get("error") or {}).get("message", "") or str(e)
        except Exception:
            message = str(e)
        print(f"Google Play API error: {message}", file=sys.stderr)
        raise SystemExit(1) from e


if __name__ == "__main__":
    main()
