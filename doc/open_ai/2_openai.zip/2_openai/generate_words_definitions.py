#!/usr/bin/env python3
"""Generate WordsDefinitions.txt from all_topics and d.txt."""

from pathlib import Path

# Must match the order in d.txt
all_topics = [
    # A1
    ["A1", "Greetings & introductions"],
    ["A1", "Numbers, dates, time"],
    ["A1", "Family & relationships"],
    ["A1", "Food & drinks"],
    ["A1", "Basic daily routines"],
    ["A1", "Home & rooms"],
    ["A1", "Furniture & household items"],
    ["A1", "Clothing & colors"],
    ["A1", "Body parts"],
    ["A1", "Basic health (feeling sick, doctor)"],
    ["A1", "Weather"],
    ["A1", "Shopping (basic items & prices)"],
    ["A1", "Transport (bus, train, taxi)"],
    ["A1", "Directions (left, right, near)"],
    ["A1", "Work (basic jobs)"],
    ["A1", "School & classroom"],
    ["A1", "Leisure activities"],
    ["A1", "Sports (basic)"],
    ["A1", "Animals"],
    ["A1", "Countries & nationalities"],
    # A2
    ["A2", "Travel & holidays"],
    ["A2", "Hotels & accommodation"],
    ["A2", "Restaurants & ordering food"],
    ["A2", "Shopping (clothes, sizes, preferences)"],
    ["A2", "Daily routines (detailed)"],
    ["A2", "Free time & hobbies"],
    ["A2", "Entertainment (TV, movies, music)"],
    ["A2", "Friends & social life"],
    ["A2", "Communication (phone, messages)"],
    ["A2", "Health & common problems"],
    ["A2", "Fitness & exercise"],
    ["A2", "City & places (bank, post office)"],
    ["A2", "Directions & navigation"],
    ["A2", "Work & jobs (tasks)"],
    ["A2", "Education & learning"],
    ["A2", "Technology basics (phone, internet)"],
    ["A2", "Weather (detailed)"],
    ["A2", "Past experiences (basic storytelling)"],
    ["A2", "Future plans (intentions)"],
    ["A2", "Basic grammar topics (present/past/future, simple conditionals)"],
    # B1
    ["B1", "Travel experiences & problems"],
    ["B1", "Culture & traditions"],
    ["B1", "Food culture & cooking"],
    ["B1", "Work & career"],
    ["B1", "Education systems"],
    ["B1", "Relationships & emotions"],
    ["B1", "Health & lifestyle"],
    ["B1", "Fitness & diet"],
    ["B1", "Media (TV, news, social media)"],
    ["B1", "Technology & mobile apps"],
    ["B1", "Environment & nature"],
    ["B1", "City vs countryside"],
    ["B1", "Shopping & consumer habits"],
    ["B1", "Money & personal finance"],
    ["B1", "Entertainment & arts"],
    ["B1", "Sports & competitions"],
    ["B1", "Communication & language learning"],
    ["B1", "Problem-solving (lost items, complaints)"],
    ["B1", "Basic politics & society"],
    ["B1", "Grammar focus: phrasal verbs, first & second conditional, past tenses"],
    # B2
    ["B2", "Society & social issues"],
    ["B2", "Education & systems"],
    ["B2", "Work-life balance"],
    ["B2", "Career development"],
    ["B2", "Business basics"],
    ["B2", "Technology impact"],
    ["B2", "Social media influence"],
    ["B2", "Environment & sustainability"],
    ["B2", "Globalization"],
    ["B2", "Culture & identity"],
    ["B2", "Ethics & moral dilemmas"],
    ["B2", "News & media analysis"],
    ["B2", "Science & innovation"],
    ["B2", "Health systems & medicine"],
    ["B2", "Travel & globalization"],
    ["B2", "Urbanization & housing"],
    ["B2", "Crime & law (basic)"],
    ["B2", "Economics (basic concepts)"],
    ["B2", "Debate & argumentation"],
    ["B2", "Grammar focus: second & third conditional, passive voice, reported speech"],
    # C1
    ["C1", "Politics & governance"],
    ["C1", "Economics & global markets"],
    ["C1", "Philosophy & ethics"],
    ["C1", "Psychology & behavior"],
    ["C1", "Advanced technology (AI, digitalization)"],
    ["C1", "Environment & climate change"],
    ["C1", "Cultural identity & diversity"],
    ["C1", "Media bias & propaganda"],
    ["C1", "Education theory"],
    ["C1", "Business strategy"],
    ["C1", "Leadership & management"],
    ["C1", "Law & justice systems"],
    ["C1", "Science & research"],
    ["C1", "Art, literature & interpretation"],
    ["C1", "Social inequality"],
    ["C1", "Global issues & geopolitics"],
    ["C1", "Innovation & entrepreneurship"],
    ["C1", "Communication strategies"],
    ["C1", "Academic writing & rhetoric"],
    [
        "C1",
        "Grammar focus: complex conditionals, inversion, advanced linking structures",
    ],
    # C2
    ["C2", "Political theory & ideology"],
    ["C2", "Advanced economics & finance"],
    ["C2", "Legal systems & case analysis"],
    ["C2", "Philosophy (deep analysis)"],
    ["C2", "Linguistics & language theory"],
    ["C2", "Literary criticism"],
    ["C2", "Advanced rhetoric & persuasion"],
    ["C2", "Scientific discourse"],
    ["C2", "Cultural discourse & identity theory"],
    ["C2", "Ethics in technology (AI, bioethics)"],
    ["C2", "Global conflicts & diplomacy"],
    ["C2", "Advanced business & corporate strategy"],
    ["C2", "Journalism & media framing"],
    ["C2", "Sociology & social theory"],
    ["C2", "Psychology (advanced concepts)"],
    ["C2", "Intercultural communication"],
    ["C2", "Humor, irony & sarcasm"],
    ["C2", "Idioms & figurative language mastery"],
    ["C2", "Register & stylistic variation"],
    [
        "C2",
        "Grammar focus: all conditionals (zero–mixed), discourse markers, stylistic nuance",
    ],
]


def make_description(level: str, topic_name: str) -> str:
    """Generate a short description for the vocabulary based on the topic."""
    return f"Vocabulary for {topic_name} at {level} level."


def format_package_def(level: str, topic_name: str, json_file_name: str) -> str:
    """Format a single PackageDef entry."""
    group_name = f"EN-DE Words {level}"
    package_name = f"{level} {topic_name}"
    description = make_description(level, topic_name)
    return f"""PackageDef(
     groupName:    '{group_name}',
     iconIndex:    4,
     packageName:  '{package_name}',
     langCode1:    'en-UK',
     langCode2:    'de-DE',
     description:  '{description}',
     authorName:   'Language Rally Team',
     authorEmail:  'languagerally.support@gmail.com',
     version:      '1.0',
     authorWebpage:'https://sites.google.com/view/language-rally',
     isPurchased:  true,
     jsonFilePath: r'JSON_to_import\\{json_file_name}',
   )"""


def main():
    script_dir = Path(__file__).parent
    d_txt_path = script_dir / "d.txt"
    output_path = script_dir / "WordsDefinitions.txt"

    # Load JSON file names from d.txt
    json_files = [
        line.strip()
        for line in d_txt_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    if len(json_files) != len(all_topics):
        raise ValueError(
            f"Length mismatch: d.txt has {len(json_files)} files, "
            f"all_topics has {len(all_topics)} entries"
        )

    entries = []
    for (level, topic_name), json_file in zip(all_topics, json_files):
        entries.append(format_package_def(level, topic_name, json_file))

    content = ",\n".join(entries) + "\n"
    output_path.write_text(content, encoding="utf-8")
    print(f"Wrote {len(entries)} package definitions to {output_path}")


if __name__ == "__main__":
    main()
