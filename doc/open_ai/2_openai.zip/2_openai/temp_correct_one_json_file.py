# this script will correct the categories in one json file: "translate_from/expressions/EN_DE_C1_Advanced_technology_AI_digitalization_EXPRESSIONS.json"
# so for example: "Anwendung" → "Application"
# this is the complete list of categories to be replaced:
# Anwendung → Application
# Betrieb → Operations
# Bildung → Education
# Biologie → Biology
# Blockchain → Blockchain
# Compliance → Compliance
# Datenschutz → Data Protection
# Design → Design
# Engineering → Engineering
# Entwicklung → Development
# Ethik → Ethics
# Finanzen → Finance
# Forensik → Forensics
# Forschung → Research
# Governance → Governance
# Hardware → Hardware
# Industrie → Industry
# Informatik → Computer Science
# Infrastruktur → Infrastructure
# Innovation → Innovation
# KI → Artificial Intelligence (AI)
# Kriminalität → Crime
# Kryptographie → Cryptography
# Kultur → Culture
# Literatur → Literature
# ML → Machine Learning (ML)
# Marketing → Marketing
# Mathematik → Mathematics
# Medien → Media
# Medizin → Medicine
# NLP → Natural Language Processing (NLP)
# Nutzererfahrung → User Experience (UX)
# Philosophie → Philosophy
# Politik → Politics
# Praxis → Practice
# Psychologie → Psychology
# Recht → Law
# Robotik → Robotics
# Sicherheit → Security
# Soziologie → Sociology
# Statistik → Statistics
# Technik → Technology
# Technologie → Technology
# Verwaltung → Administration
# Wirtschaft → Economy
# Wissenschaft → Science
# Ökologie → Ecology
# Ökonomie → Economics

import os

REPLACEMENTS: dict[str, str] = {
    "Anwendung":      "Application",
    "Betrieb":        "Operations",
    "Bildung":        "Education",
    "Biologie":       "Biology",
    "Blockchain":     "Blockchain",
    "Compliance":     "Compliance",
    "Datenschutz":    "Data Protection",
    "Design":         "Design",
    "Engineering":    "Engineering",
    "Entwicklung":    "Development",
    "Ethik":          "Ethics",
    "Finanzen":       "Finance",
    "Forensik":       "Forensics",
    "Forschung":      "Research",
    "Governance":     "Governance",
    "Hardware":       "Hardware",
    "Industrie":      "Industry",
    "Informatik":     "Computer Science",
    "Infrastruktur":  "Infrastructure",
    "Innovation":     "Innovation",
    "KI":             "Artificial Intelligence (AI)",
    "Kriminalität":   "Crime",
    "Kryptographie":  "Cryptography",
    "Kultur":         "Culture",
    "Literatur":      "Literature",
    "ML":             "Machine Learning (ML)",
    "Marketing":      "Marketing",
    "Mathematik":     "Mathematics",
    "Medien":         "Media",
    "Medizin":        "Medicine",
    "NLP":            "Natural Language Processing (NLP)",
    "Nutzererfahrung": "User Experience (UX)",
    "Philosophie":    "Philosophy",
    "Politik":        "Politics",
    "Praxis":         "Practice",
    "Psychologie":    "Psychology",
    "Recht":          "Law",
    "Robotik":        "Robotics",
    "Sicherheit":     "Security",
    "Soziologie":     "Sociology",
    "Statistik":      "Statistics",
    "Technik":        "Technology",
    "Technologie":    "Technology",
    "Verwaltung":     "Administration",
    "Wirtschaft":     "Economy",
    "Wissenschaft":   "Science",
    "Ökologie":       "Ecology",
    "Ökonomie":       "Economics",
}

FILE_NAME = os.path.join(
    os.path.dirname(__file__),
    "translate_from", "expressions",
    "EN_DE_C1_Advanced_technology_AI_digitalization_EXPRESSIONS.json",
)


def main() -> None:
    raw = FILE_NAME.encode()  # just to declare; read below
    with open(FILE_NAME, "rb") as f:
        raw = f.read()

    updated = raw
    total_replacements = 0

    for old, new in REPLACEMENTS.items():
        # Match the exact JSON field value to avoid partial-string collisions.
        old_snippet = f'"category_name": "{old}"'.encode("utf-8")
        new_snippet = f'"category_name": "{new}"'.encode("utf-8")
        count = updated.count(old_snippet)
        if count:
            updated = updated.replace(old_snippet, new_snippet)
            print(f"  {old!r:25s} → {new!r}  ({count}×)")
            total_replacements += count

    if updated == raw:
        print("No replacements made – file already up to date.")
        return

    with open(FILE_NAME, "wb") as f:
        f.write(updated)

    print(f"\nDone – {total_replacements} replacement(s) written to:\n  {FILE_NAME}")


if __name__ == "__main__":
    main()
