# This python script will translate the content of multiple json files from english to the target language with the help of the openai api
# for a better translation, we will provide the German meaning of the items, too
# This is the structure of the json file:
# |
# {
#     "source_language": "EN",
#     "target_language": "DE",
#     "source_pre_tag": "",
#     "source_expression": "abstraction",
#     "source_post_tag": "n.",
#     "target_pre_tag": "die",
#     "target_expression": "Abstraktion",
#     "target_post_tag": "Abstraktionen",
#     "examples": [
#       {
#         "source": "The sculpture is an abstraction of human emotion.",
#         "target": "Die Skulptur ist eine Abstraktion der menschlichen Emotionen."
#       }
#     ],
#     "categories": [
#       {
#         "category_name": "Style"
#       },
#       {
#         "category_name": "Conceptual"
#       }
#     ]
#   },
# ... ]
# the target language is provided as an argument to the script
# all the imput files available from the  translate_from/expressions and translate_from/words folders must be processed one by one
# the model shall not hallucinate, it shall only translate the content of the json file into the target language
# the output file will contain the same fields and structure as the input file, where the source language is EN and the target language is the one provided as an argument to the script
# the output will be a new json file with similar name to the input so for example
# EN_<target language code>_C1_Academic_writing_rhetoric_WORDS.json
# or EN_<target language code>_A1_Furniture_household_items_EXPRESSIONS.json
# The model shall receive both the English and the German meaning of the items, in order to achieve a better translation
# the "target_pre_tag" shall be provided as follows:
# - in case nouns and languages like the German (or where the nouns hage gender), this tag must contain the article article der/die/das, or in case of Spanish el/la
# the "target_post_tag" shall be provided as follows:
# - in case verbs this tag must contain past tense
# - in case of nouns plural form, conjugation hint.
# All examples shall be translated into the target language, too (into the "target" field)


import json
import os
import sys
import time

import openai
from dotenv import load_dotenv

load_dotenv(override=True)

client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

MODEL = "gpt-5.4-mini"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_BASE = os.path.join(BASE_DIR, "translate_from")
OUTPUT_BASE = os.path.join(BASE_DIR, "translate_to")

LANGUAGE_NAMES: dict[str, str] = {
    "ES": "Spanish",
    "FR": "French",
    "DE": "German",
    "IT": "Italian",
    "JA": "Japanese",
    "ZH": "Chinese",
    "KO": "Korean",
    "PT": "Portuguese",
    "RU": "Russian",
    "AR": "Arabic",
    "RO": "Romanian",
    "HU": "Hungarian",
    "NL": "Dutch",
    "SV": "Swedish",
    "NO": "Norwegian",
    "DA": "Danish",
    "FI": "Finnish",
    "HI": "Hindi",
    "TR": "Turkish",
    "VI": "Vietnamese",
    "TH": "Thai",
    "id": "Indonesian",
    "MS": "Malay",
    "FIL": "Filipino",
    "HE": "Hebrew",
}

BATCH_SIZE = 10  # items per API call
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds, multiplied by attempt number


# ── helpers ──────────────────────────────────────────────────────────────────


def get_lang_name(code: str) -> str:
    return LANGUAGE_NAMES.get(code.upper(), code)


def translate_batch(
    items: list[dict], lang_code: str, lang_name: str, attempt: int = 1
) -> list[dict]:
    """Send a batch of EN/DE items to the model and get back the target-language fields."""
    model_input = [
        {
            "id": i,
            "en_pre_tag": item.get("source_pre_tag", ""),
            "en_expression": item.get("source_expression", ""),
            "en_post_tag": item.get("source_post_tag", ""),
            "de_pre_tag": item.get("target_pre_tag", ""),
            "de_expression": item.get("target_expression", ""),
            "de_post_tag": item.get("target_post_tag", ""),
            "en_examples": [ex.get("source", "") for ex in item.get("examples", [])],
        }
        for i, item in enumerate(items)
    ]

    system_prompt = f"""You are a professional linguist translating vocabulary items from English to {lang_name}.
Each item provides the English expression (with part-of-speech tag) and its German equivalent as reference.

Return a JSON object with key "items" — an array with one entry per input item containing:
  "id"              : same integer as input
  "target_pre_tag"  : grammatical article / gender marker in {lang_name} (e.g. "el"/"la", "der"/"die"/"das"); empty string if not applicable
  "target_expression": faithful translation of the expression into {lang_name}
  "target_post_tag" : plural form for nouns; past tense for verbs; empty string otherwise
  "target_examples" : array of translated example sentences, same order and count as "en_examples"

Rules: do NOT hallucinate, do NOT add or remove items, do NOT change id values, return valid JSON only."""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": json.dumps({"items": model_input}, ensure_ascii=False),
                },
            ],
            response_format={"type": "json_object"},
            temperature=0.1,
        )
        return json.loads(response.choices[0].message.content).get("items", [])
    except Exception as exc:
        if attempt < MAX_RETRIES:
            print(f"    Retry {attempt}/{MAX_RETRIES} after error: {exc}")
            time.sleep(RETRY_DELAY * attempt)
            return translate_batch(items, lang_code, lang_name, attempt + 1)
        raise


def build_output_item(original: dict, translated: dict, lang_code: str) -> dict:
    en_examples = [ex.get("source", "") for ex in original.get("examples", [])]
    tgt_examples = translated.get("target_examples", [])
    examples_out = [
        {"source": src, "target": tgt_examples[i] if i < len(tgt_examples) else ""}
        for i, src in enumerate(en_examples)
    ]
    return {
        "source_language": "EN",
        "target_language": lang_code.upper(),
        "source_pre_tag": original.get("source_pre_tag", ""),
        "source_expression": original.get("source_expression", ""),
        "source_post_tag": original.get("source_post_tag", ""),
        "target_pre_tag": translated.get("target_pre_tag", ""),
        "target_expression": translated.get("target_expression", ""),
        "target_post_tag": translated.get("target_post_tag", ""),
        "examples": examples_out,
        "categories": original.get("categories", []),
    }


def output_filename(input_filename: str, lang_code: str) -> str:
    # EN_DE_A1_Animals_WORDS.json  →  EN_ES_A1_Animals_WORDS.json
    parts = input_filename.split("_")
    if len(parts) >= 2:
        parts[1] = lang_code.upper()
    return "_".join(parts)


# ── per-file processing ───────────────────────────────────────────────────────


def process_file(
    input_path: str, subfolder: str, lang_code: str, lang_name: str
) -> None:
    filename = os.path.basename(input_path)
    out_name = output_filename(filename, lang_code)
    out_dir = os.path.join(OUTPUT_BASE, lang_code.upper(), subfolder)
    out_path = os.path.join(out_dir, out_name)

    if os.path.exists(out_path):
        print(f"  SKIP (exists): {out_name}")
        return

    os.makedirs(out_dir, exist_ok=True)

    with open(input_path, encoding="utf-8") as f:
        items = json.load(f)

    total_batches = (len(items) + BATCH_SIZE - 1) // BATCH_SIZE
    print(f"  {filename}  ({len(items)} items, {total_batches} batches) …")
    output_items: list[dict] = []

    for idx in range(0, len(items), BATCH_SIZE):
        batch = items[idx : idx + BATCH_SIZE]
        batch_num = idx // BATCH_SIZE + 1
        print(
            f"    [{batch_num}/{total_batches}] {len(batch)} items …",
            end=" ",
            flush=True,
        )

        translated_batch = translate_batch(batch, lang_code, lang_name)
        by_id = {t["id"]: t for t in translated_batch}

        for i, original in enumerate(batch):
            output_items.append(
                build_output_item(original, by_id.get(i, {}), lang_code)
            )

        print("ok")
        time.sleep(0.3)

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output_items, f, ensure_ascii=False, indent=2)

    print(f"    → {out_path}")


# ── entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    lang_code = "ES"
    lang_code = lang_code.upper()
    lang_name = get_lang_name(lang_code)
    print(f"Target language: {lang_name} ({lang_code})\n")

    for subfolder in ("words", "expressions"):
        in_dir = os.path.join(INPUT_BASE, subfolder)
        if not os.path.isdir(in_dir):
            print(f"Folder not found, skipping: {in_dir}")
            continue

        files = sorted(f for f in os.listdir(in_dir) if f.lower().endswith(".json"))
        print(f"\n{'='*60}")
        print(f"  {subfolder}/  –  {len(files)} file(s)")
        print(f"{'='*60}")
        for filename in files:
            process_file(
                os.path.join(in_dir, filename), subfolder, lang_code, lang_name
            )

    print("\nAll done.")


if __name__ == "__main__":
    main()
