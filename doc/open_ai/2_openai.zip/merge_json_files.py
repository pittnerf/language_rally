# This script will merge JSON files from a "words" and "expressions" folders into a single JSON file and store it into the "merged" folder
# INPUT_FOLDER_BASE:  the folder that contains subfolders with the short code of the language, example: "AR", "ES", "FR", "HU", "IT", "JA", "KO", "PT", "RU", "RO", "ZH", "NL", "SV", "NO", "DA", "FI", "HI", "TR", "VI", "TH", "ID", "MS", "FIL", "HE"
# Each of these folders contains two subfolders: "words" and "expressions"
# The script will find the pairs and merge the JSON files from the "words" and "expressions" folders into a single JSON file and store it into the "merged/<language_code>" folder
# Example: DE/words/EN_DE_A1_Animals_WORDS.json and DE/expressions/EN_DE_A1_Animals_EXPRESSIONS.json will be merged into a single JSON file called EN_DE_A1_Animals.json and stored into the "merged/DE" folder
# OUTPUT_FOLDER_BASE: the folder that will contain the merged JSON file
#
from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# INPUT_FOLDER_BASE = os.path.join(os.path.dirname(__file__), "translate_to")
INPUT_FOLDER_BASE = os.path.join(os.path.dirname(__file__), "translated_corrected")
OUTPUT_FOLDER_BASE = os.path.join(os.path.dirname(__file__), "translated_merged")


@dataclass(frozen=True)
class Pair:
    language_code: str
    base_name: str  # filename without _WORDS/_EXPRESSIONS suffix (and without .json)
    words_path: Path | None
    expressions_path: Path | None


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")


def _strip_suffix(filename: str, suffix: str) -> str | None:
    if not filename.endswith(suffix):
        return None
    return filename[: -len(suffix)]


def _discover_pairs(input_base: Path, language_filter: set[str] | None) -> list[Pair]:
    pairs: dict[tuple[str, str], Pair] = {}

    for lang_dir in sorted([p for p in input_base.iterdir() if p.is_dir()]):
        language_code = lang_dir.name
        if language_filter is not None and language_code not in language_filter:
            continue

        words_dir = lang_dir / "words"
        expressions_dir = lang_dir / "expressions"

        if words_dir.is_dir():
            for p in sorted(words_dir.glob("*.json")):
                base = _strip_suffix(p.name, "_WORDS.json")
                if base is None:
                    continue
                key = (language_code, base)
                existing = pairs.get(key) or Pair(
                    language_code=language_code,
                    base_name=base,
                    words_path=None,
                    expressions_path=None,
                )
                pairs[key] = Pair(
                    language_code=existing.language_code,
                    base_name=existing.base_name,
                    words_path=p,
                    expressions_path=existing.expressions_path,
                )

        if expressions_dir.is_dir():
            for p in sorted(expressions_dir.glob("*.json")):
                base = _strip_suffix(p.name, "_EXPRESSIONS.json")
                if base is None:
                    continue
                key = (language_code, base)
                existing = pairs.get(key) or Pair(
                    language_code=language_code,
                    base_name=base,
                    words_path=None,
                    expressions_path=None,
                )
                pairs[key] = Pair(
                    language_code=existing.language_code,
                    base_name=existing.base_name,
                    words_path=existing.words_path,
                    expressions_path=p,
                )

    # stable output ordering
    return sorted(pairs.values(), key=lambda pr: (pr.language_code, pr.base_name))


def _infer_langs(
    words_data: Any, expressions_data: Any
) -> tuple[str | None, str | None]:
    # Inputs are typically lists of objects containing source_language/target_language
    for dataset in (words_data, expressions_data):
        if isinstance(dataset, list) and dataset:
            first = dataset[0]
            if isinstance(first, dict):
                return (
                    first.get("source_language"),
                    first.get("target_language"),
                )
    return (None, None)


def merge_all(
    *,
    input_folder_base: Path,
    output_folder_base: Path,
    language_filter: set[str] | None = None,
    dry_run: bool = False,
) -> dict[str, int]:
    stats = {
        "languages_seen": 0,
        "pairs_seen": 0,
        "pairs_merged": 0,
        "pairs_missing_words": 0,
        "pairs_missing_expressions": 0,
        "output_files_written": 0,
    }

    pairs = _discover_pairs(input_folder_base, language_filter)
    stats["pairs_seen"] = len(pairs)
    stats["languages_seen"] = len({p.language_code for p in pairs})

    for pr in pairs:
        if pr.words_path is None:
            stats["pairs_missing_words"] += 1
        if pr.expressions_path is None:
            stats["pairs_missing_expressions"] += 1

        if pr.words_path is None or pr.expressions_path is None:
            # Skip incomplete pairs; the script is intended to merge pairs.
            continue

        words_data = _load_json(pr.words_path)
        expressions_data = _load_json(pr.expressions_path)

        source_language, target_language = _infer_langs(words_data, expressions_data)

        merged = {
            "schema_version": 1,
            "language_code": pr.language_code,
            "source_language": source_language,
            "target_language": target_language,
            "base_name": pr.base_name,
            "counts": {
                "words": len(words_data) if isinstance(words_data, list) else None,
                "expressions": (
                    len(expressions_data)
                    if isinstance(expressions_data, list)
                    else None
                ),
            },
            "words": words_data,
            "expressions": expressions_data,
        }

        out_path = output_folder_base / pr.language_code / f"{pr.base_name}.json"
        if not dry_run:
            _write_json(out_path, merged)
            stats["output_files_written"] += 1
        stats["pairs_merged"] += 1

    return stats


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Merge translated JSON files from translated_corrected/<LANG>/{words,expressions}/ "
            "into translated_merged/<LANG>/<base>.json"
        )
    )
    parser.add_argument(
        "--input-base",
        default=INPUT_FOLDER_BASE,
        help='Base folder containing language subfolders (default: "translated_corrected" next to this script).',
    )
    parser.add_argument(
        "--output-base",
        default=OUTPUT_FOLDER_BASE,
        help='Base folder to write merged outputs (default: "translated_merged" next to this script).',
    )
    parser.add_argument(
        "--language",
        action="append",
        default=None,
        help="Limit to specific language code(s) (repeatable), e.g. --language DE --language AR",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Discover and validate pairs, but do not write output files.",
    )

    args = parser.parse_args()
    input_base = Path(args.input_base).expanduser().resolve()
    output_base = Path(args.output_base).expanduser().resolve()
    language_filter = set(args.language) if args.language else None

    stats = merge_all(
        input_folder_base=input_base,
        output_folder_base=output_base,
        language_filter=language_filter,
        dry_run=bool(args.dry_run),
    )

    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
