# this script counts the number of characters to translate
# it will take all json files from the translate_from/words and /expressions folders
# will read all the itesm from the json files
# will count:
# - the length of the "source_expression", for example "source_expression": "This is a dog", so the length is 13 characters
# - the length of "source" from the list of "examples": [    {        "source": "This is a dog.",      "target": "Das ist ein Hund."       }     ],
# - will collect all unqie categories from the  list of "categories": [ { "category_name": "Pets"     }, so "Pets" and at the end of the file will counth their lengths, too
# At the end of each file, it has to display the file name, thetotal number of characters to translate (source_expression + source from examples, and the total lenght of the categories)
# as well as the grand total of all files.
import json
import os

BASE_DIR = os.path.join(os.path.dirname(__file__), "translate_from")
SUBFOLDERS = ["words", "expressions"]


def word_count(text: str) -> int:
    return len(text.split())


def count_file(path: str) -> tuple[int, int, int, int, set[str]]:
    """Return (expr_chars, expr_words, example_chars, example_words, unique_categories)."""
    with open(path, encoding="utf-8") as f:
        items = json.load(f)

    expr_chars = 0
    expr_words = 0
    example_chars = 0
    example_words = 0
    categories: set[str] = set()

    for item in items:
        text = item.get("source_expression", "")
        expr_chars += len(text)
        expr_words += word_count(text)
        for ex in item.get("examples", []):
            src = ex.get("source", "")
            example_chars += len(src)
            example_words += word_count(src)
        for cat in item.get("categories", []):
            name = cat.get("category_name", "")
            if name:
                categories.add(name)

    return expr_chars, expr_words, example_chars, example_words, categories


def main() -> None:
    grand_expr_chars = 0
    grand_expr_words = 0
    grand_example_chars = 0
    grand_example_words = 0
    all_categories: set[str] = set()

    for subfolder in SUBFOLDERS:
        folder = os.path.join(BASE_DIR, subfolder)
        if not os.path.isdir(folder):
            print(f"Folder not found, skipping: {folder}")
            continue

        json_files = sorted(
            f for f in os.listdir(folder) if f.lower().endswith(".json")
        )

        print(f"\n{'═' * 74}")
        print(f"  Folder: translate_from/{subfolder}  ({len(json_files)} files)")
        print(f"{'═' * 74}")

        for filename in json_files:
            path = os.path.join(folder, filename)
            expr_chars, expr_words, example_chars, example_words, categories = count_file(path)
            total_chars = expr_chars + example_chars
            total_words = expr_words + example_words
            cat_chars = sum(len(c) for c in categories)

            print(f"\n  {filename}")
            print(f"    {'':30s} {'chars':>10}  {'words':>8}")
            print(f"    {'source_expression':30s} {expr_chars:>10,}  {expr_words:>8,}")
            print(f"    {'example source':30s} {example_chars:>10,}  {example_words:>8,}")
            print(f"    {'subtotal (to translate)':30s} {total_chars:>10,}  {total_words:>8,}")
            print(f"    unique categories       : {len(categories):>8,}  ({cat_chars:,} chars)")
            print(f"    categories              : {', '.join(sorted(categories))}")

            grand_expr_chars    += expr_chars
            grand_expr_words    += expr_words
            grand_example_chars += example_chars
            grand_example_words += example_words
            all_categories      |= categories

    grand_total_chars = grand_expr_chars + grand_example_chars
    grand_total_words = grand_expr_words + grand_example_words
    cat_total_chars = sum(len(c) for c in all_categories)

    print(f"\n{'═' * 74}")
    print("  GRAND TOTAL")
    print(f"{'═' * 74}")
    print(f"  {'':30s} {'chars':>10}  {'words':>8}")
    print(f"  {'source_expression':30s} {grand_expr_chars:>10,}  {grand_expr_words:>8,}")
    print(f"  {'example source':30s} {grand_example_chars:>10,}  {grand_example_words:>8,}")
    print(f"  {'total (to translate)':30s} {grand_total_chars:>10,}  {grand_total_words:>8,}")
    print(f"  unique categories       : {len(all_categories):>10,}  ({cat_total_chars:,} chars)")
    print(f"  categories              : {', '.join(sorted(all_categories))}")
    print()


if __name__ == "__main__":
    main()
