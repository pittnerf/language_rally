# This python script will translate the content of multiple json files from english to the target languages with the help of the openai api
# it will translate only the target_expression field, and the examples/target field, the other fields will be kept as is.
# This is the structure of the json file:
# |
# {
#     "source_language": "EN",
#     "target_language": "DE",
#     "source_pre_tag": "",
#     "source_expression": "abstraction",
#     "source_post_tag": "n.",
#     "target_pre_tag": "die",
#     "target_expression": "Abstraktion",
#     "target_post_tag": "Abstraktionen",
#     "examples": [
#       {
#         "source": "The sculpture is an abstraction of human emotion.",
#         "target": "Die Skulptur ist eine Abstraktion der menschlichen Emotionen."
#       }
#     ],
#     "categories": [
#       {
#         "category_name": "Style"
#       },
#       {
#         "category_name": "Conceptual"
#       }
#     ]
#   },
# ... ]
# all the input files available from the translate_from/expressions and translate_from/words folders are processed one by one
# each batch of items is translated into all target languages in a SINGLE OpenAI API call
# the output file will contain the same fields and structure as the input file
# the output will be a new json file per target language, e.g.:
# EN_ES_C1_Academic_writing_rhetoric_WORDS.json
# EN_FR_A1_Furniture_household_items_EXPRESSIONS.json


import json
import os
import time
from datetime import datetime
from typing import IO

import openai
from dotenv import load_dotenv

load_dotenv(override=True)

client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

MODEL = "gpt-5.4-mini"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_BASE = os.path.join(BASE_DIR, "translate_from")
OUTPUT_BASE = os.path.join(BASE_DIR, "translate_to")

# The 12 target languages translated in every single API call
TARGET_LANGUAGES: list[tuple[str, str]] = [
    ("ES", "Spanish"),
    ("FR", "French"),
    ("DE", "German"),
    ("IT", "Italian"),
    ("JA", "Japanese"),
    ("ZH", "Chinese"),
    ("KO", "Korean"),
    ("PT", "Portuguese"),
    ("RU", "Russian"),
    ("AR", "Arabic"),
    ("RO", "Romanian"),
    ("HU", "Hungarian"),
]

# Languages that use grammatical gender (affects target_pre_tag guidance)
GENDERED_LANGS = {"ES", "FR", "IT", "PT", "RO", "AR"}

# With 12 languages per call the response is large. If the model returns empty translations
# for any item, those items are detected and retried automatically (see translate_batch).
BATCH_SIZE = 10
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds × attempt number

LOG_FILE = os.path.join(
    BASE_DIR, "translate_content_into_multiple_languages_target_expressions.log"
)

# ── logging ───────────────────────────────────────────────────────────────────

_log_fh: IO[str] | None = None


def log(*args, end: str = "\n", flush: bool = False, **kwargs) -> None:
    """Drop-in replacement for print() that mirrors output to the log file."""
    print(*args, end=end, flush=flush, **kwargs)
    if _log_fh is not None:
        print(*args, end=end, **kwargs, file=_log_fh)
        if flush:
            _log_fh.flush()


# ── translation ───────────────────────────────────────────────────────────────


def _build_system_prompt(langs: list[tuple[str, str]]) -> str:
    lang_list = "\n".join(
        # f'  "{code}": "{name}"{"  (grammatical gender applies)" if code in GENDERED_LANGS else ""}'
        f'  "{code}": "{name}"'
        for code, name in langs
    )
    return f"""You are a professional linguist. Translate expressions and words and their examples provided in English into multiple target languages at once.
Each item includes:
  - en_expression: the English headword or phrase
  - en_pre_tag / en_post_tag: optional labels (e.g. part of speech like "n.", "v.", "adj.") — use them to pick the correct sense and word class
  - en_examples: example sentences in English (same order as given)

Part-of-speech and lemma rules (critical):
  - Match the sense implied by en_pre_tag and en_post_tag. If the post_tag marks a noun (e.g. "n."), translate the noun, not the verb form of the same English word.
  - Example: en_expression "shower" with post_tag "n." → German noun lemma "Dusche" (capitalized), NOT the verb infinitive "duschen".
  - For German nouns, use the standard dictionary noun form (capitalized); for verbs, use the infinitive form expected in dictionaries for that language.
  - Languages with grammatical gender ({", ".join(sorted(GENDERED_LANGS))}): still output target_expression without articles in that field; let the example sentences use natural agreement.

Prefer translating meaning over word-for-word; use correct grammar throughout. Do not change the English example wording (only translate it).
Translate examples first and use the same chosen sense/lemma in both "target_examples" and "target_expression" (the headword must appear in the same form in examples where the word is used).

Return a JSON object with key "items" — one entry per input item:
  "id": same integer as input
  "translations": object with one key per language code below, each value containing:

    "target_examples" — Array of translated sentences — EXACT same length and order as en_examples. If en_examples has N items, this array has N strings. Every string must be non-empty.

    "target_expression" — Translation of en_expression for the sense given by the tags. MUST NEVER be empty or whitespace-only.
                          Before translating the en_expression into target_expression check the en_examples in order to use a proper translation.
                          Headword only: no leading/trailing articles or prefixes unless they are inseparable in that language.

Target language codes:
{lang_list}

Rules: do NOT hallucinate · stay faithful to English source meaning · output ALL items ·
do NOT change id values · return valid JSON only."""


def _call_api(
    model_input: list[dict], langs: list[tuple[str, str]]
) -> tuple[list[dict], str]:
    """Raw API call. Returns (items_list, finish_reason)."""
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": _build_system_prompt(langs)},
            {
                "role": "user",
                "content": json.dumps({"items": model_input}, ensure_ascii=False),
            },
        ],
        response_format={"type": "json_object"},
        temperature=0.1,
    )
    finish_reason = response.choices[0].finish_reason
    items = json.loads(response.choices[0].message.content).get("items", [])
    return items, finish_reason


def translate_batch(
    items: list[dict],
    langs: list[tuple[str, str]],
    attempt: int = 1,
) -> list[dict]:
    """One API call → translations for all target languages for this batch.

    After each call the response is validated for completeness:
    - If finish_reason == "length" the model was cut off by the token limit.
    - Any item IDs missing from the response are retried automatically.
    Items are sent with their enumerate-based IDs so retries can use the same IDs
    without any remapping.
    """
    # Build model input preserving the caller's item ordering as IDs.
    model_input = [
        {
            "id": i,
            "en_pre_tag": item.get("source_pre_tag", "") or "",
            "en_expression": item.get("source_expression", "") or "",
            "en_post_tag": item.get("source_post_tag", "") or "",
            "en_examples": [ex.get("source", "") for ex in item.get("examples", [])],
        }
        for i, item in enumerate(items)
    ]

    try:
        result_items, finish_reason = _call_api(model_input, langs)
    except Exception as exc:
        if attempt < MAX_RETRIES:
            log(f"\n    ERROR (attempt {attempt}): {exc} — retrying full batch…")
            time.sleep(RETRY_DELAY * attempt)
            return translate_batch(items, langs, attempt + 1)
        raise

    # ── auto-correct misplaced values ──────────────────────────────────────────
    # Must run before the completeness check so rescued items are not re-fetched.
    # rescued = _fix_misplaced_values(result_items, langs)
    # if rescued:
    #    log(
    #        f"\n    INFO: auto-corrected {rescued} misplaced pre_tag→expression value(s)."
    #    )

    # ── completeness check ─────────────────────────────────────────────────────
    # Failure modes that produce bad or silent output:
    #   1. Item ID absent from response entirely (model skipped it)
    #   2. target_expression missing/empty for one or more languages
    #   3. target_examples wrong length vs en_examples, or any example string empty

    if finish_reason == "length":
        log("\n    WARNING: model output was cut off (finish_reason=length).")

    expected_example_counts = {
        i: len(batch_item.get("examples") or []) for i, batch_item in enumerate(items)
    }

    def _ids_needing_retry(
        result: list[dict], lang_codes: list[str]
    ) -> tuple[set[int], set[str]]:
        """IDs missing from the response or incomplete per language (expression or examples)."""
        returned_ids = {t["id"] for t in result}
        bad: set[int] = set(range(len(items))) - returned_ids
        bad_langs: set[str] = set()

        for row in result:
            tid = row["id"]
            translations = row.get("translations") or {}
            n_expected = expected_example_counts.get(tid, 0)

            for code in lang_codes:
                tr = translations.get(code) or {}
                expr = tr.get("target_expression", "")
                if not (isinstance(expr, str) and expr.strip()):
                    bad.add(tid)
                    bad_langs.add(code)
                    break

                te = tr.get("target_examples")
                if not isinstance(te, list):
                    bad.add(tid)
                    bad_langs.add(code)
                    break
                if len(te) != n_expected:
                    bad.add(tid)
                    bad_langs.add(code)
                    break
                if n_expected and any(
                    not isinstance(s, str) or not s.strip() for s in te
                ):
                    bad.add(tid)
                    bad_langs.add(code)
                    break

        return bad, bad_langs

    lang_codes = [code for code, _ in langs]
    bad_ids, bad_langs = _ids_needing_retry(result_items, lang_codes)

    if bad_ids and attempt < MAX_RETRIES:
        log(
            f"\n    WARNING: {len(bad_ids)}/{len(items)} item(s) missing, empty "
            f"target_expression, or bad target_examples (ids {bad_ids}, langs {bad_langs}) "
            f"— retrying…"
        )
        time.sleep(RETRY_DELAY)
        retry_model_input = [model_input[i] for i in sorted(bad_ids)]
        retry_items, _ = _call_api(retry_model_input, langs)
        # _fix_misplaced_values(retry_items, langs)
        # Replace/add the retried results (overwrite originals by id)
        by_id = {t["id"]: t for t in result_items}
        for r in retry_items:
            by_id[r["id"]] = r
        result_items = list(by_id.values())
        # Final check
        still_bad, still_bad_langs = _ids_needing_retry(result_items, lang_codes)
        if still_bad:
            log(
                f"    WARNING: {len(still_bad)} item(s) still incomplete after retry "
                f"(ids {still_bad} and languages {still_bad_langs}) — those items will have empty translations."
            )
    elif bad_ids:
        log(
            f"\n    WARNING: {len(bad_ids)} item(s) incomplete and no retries left "
            f"— those items will have empty translations."
        )

    return result_items


# ── output helpers ────────────────────────────────────────────────────────────


def build_output_item(original: dict, lang_data: dict, lang_code: str) -> dict:
    en_examples = [ex.get("source", "") for ex in original.get("examples", [])]
    tgt_examples = lang_data.get("target_examples", [])
    examples_out = [
        {"source": src, "target": tgt_examples[i] if i < len(tgt_examples) else ""}
        for i, src in enumerate(en_examples)
    ]
    return {
        "source_language": "EN",
        "target_language": lang_code.upper(),
        "source_pre_tag": original.get("source_pre_tag", ""),
        "source_expression": original.get("source_expression", ""),
        "source_post_tag": original.get("source_post_tag", ""),
        "target_pre_tag": "",  # lang_data.get("target_pre_tag", ""),
        "target_expression": lang_data.get("target_expression", ""),
        "target_post_tag": "",  # lang_data.get("target_post_tag", ""),
        "examples": examples_out,
        "categories": original.get("categories", []),
    }


def output_filename(input_filename: str, lang_code: str) -> str:
    # EN_DE_A1_Animals_WORDS.json  →  EN_ES_A1_Animals_WORDS.json
    parts = input_filename.split("_")
    if len(parts) >= 2:
        parts[1] = lang_code.upper()
    return "_".join(parts)


# ── per-file processing ───────────────────────────────────────────────────────


def process_file(input_path: str, subfolder: str) -> None:
    filename = os.path.basename(input_path)

    # Determine which languages still need output files for this input file
    pending: list[tuple[str, str]] = []
    for lang_code, lang_name in TARGET_LANGUAGES:
        out_dir = os.path.join(OUTPUT_BASE, lang_code, subfolder)
        out_path = os.path.join(out_dir, output_filename(filename, lang_code))
        if os.path.exists(out_path):
            log(f"  SKIP [{lang_code}]: {output_filename(filename, lang_code)}")
        else:
            pending.append((lang_code, lang_name))

    if not pending:
        return

    with open(input_path, encoding="utf-8") as f:
        items = json.load(f)

    # Accumulate per-language output lists
    lang_outputs: dict[str, list[dict]] = {code: [] for code, _ in pending}

    total_batches = (len(items) + BATCH_SIZE - 1) // BATCH_SIZE
    langs_str = ", ".join(c for c, _ in pending)
    log(f"\n  {filename}  ({len(items)} items, {total_batches} batches)")
    log(f"  Languages: {langs_str}")

    for idx in range(0, len(items), BATCH_SIZE):
        batch = items[idx : idx + BATCH_SIZE]
        batch_num = idx // BATCH_SIZE + 1
        log(
            f"    [{batch_num}/{total_batches}] {len(batch)} items …",
            end=" ",
            flush=True,
        )

        translated_batch = translate_batch(batch, pending)
        by_id = {t["id"]: t for t in translated_batch}

        missing_count = sum(1 for i in range(len(batch)) if i not in by_id)
        status = (
            f"ok ({len(batch) - missing_count}/{len(batch)} items)"
            if missing_count == 0
            else f"PARTIAL ({len(batch) - missing_count}/{len(batch)} items translated)"
        )

        for i, original in enumerate(batch):
            item_translations = by_id.get(i, {}).get("translations", {})
            for lang_code, _ in pending:
                lang_data = item_translations.get(lang_code, {})
                lang_outputs[lang_code].append(
                    build_output_item(original, lang_data, lang_code)
                )

        log(status)
        time.sleep(0.3)

    # Write one output file per language
    for lang_code, _ in pending:
        out_dir = os.path.join(OUTPUT_BASE, lang_code, subfolder)
        out_path = os.path.join(out_dir, output_filename(filename, lang_code))
        os.makedirs(out_dir, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(lang_outputs[lang_code], f, ensure_ascii=False, indent=2)
        log(f"    → [{lang_code}] {out_path}")


# ── entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    global _log_fh
    _log_fh = open(LOG_FILE, "a", encoding="utf-8")
    try:
        run_start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log(f"\n{'#'*60}")
        log(f"# Run started: {run_start}")
        log(f"{'#'*60}")

        langs_str = ", ".join(f"{c} ({n})" for c, n in TARGET_LANGUAGES)
        log(
            f"Translating into {len(TARGET_LANGUAGES)} languages simultaneously:\n  {langs_str}\n"
        )

        for subfolder in ("words", "expressions"):
            in_dir = os.path.join(INPUT_BASE, subfolder)
            if not os.path.isdir(in_dir):
                log(f"Folder not found, skipping: {in_dir}")
                continue

            files = sorted(f for f in os.listdir(in_dir) if f.lower().endswith(".json"))
            log(f"\n{'='*60}")
            log(f"  {subfolder}/  –  {len(files)} file(s)")
            log(f"{'='*60}")
            for filename in files:
                process_file(os.path.join(in_dir, filename), subfolder)

        run_end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log(f"\nAll done.  (finished: {run_end})")
    finally:
        _log_fh.close()
        _log_fh = None


if __name__ == "__main__":
    main()
