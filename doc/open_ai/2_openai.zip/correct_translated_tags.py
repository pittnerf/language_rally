# This script will check all the JSON files in the translated_check folder and its subfolders
# and will check the following tags:
# - "target_pre_tag"
# - "target_expression"
# - "target_post_tag"
# - "examples" list of "source" and "target". A Sample of EN-RO example:
# {
#     "source_language": "EN",
#     "target_language": "RO",
#     "source_pre_tag": "",
#     "source_expression": "debate",
#     "source_post_tag": "",
#     "target_pre_tag": "dezbaterea",
#     "target_expression": "dezbatere",
#     "target_post_tag": "dezbateri",
#     "examples": [
#       {
#         "source": "The debate lasted two hours and clarified key issues.",
#         "target": "Dezbaterea a durat două ore și a clarificat problemele-cheie."
#       }
#     ],
#     "categories": [
#       {
#         "category_name": "Debate"
#       },
#       {
#         "category_name": "Discourse"
#       }
#     ]
#   },
#
# A. Checks to be performed - python level, without the help of an AI model:
# Is the "target_expression" not empty?
# Is each of the "target" fields in the "examples" not empty?
# The script must list all the files that do not pass the checks.
#
# B. Checks to be performed - AI model level (chatgpt 4.mini):
# The scipt must create a new file with the corrected content, by keeping the UTF-8 encoding and save it to the translated_corrected folder. The original file must be kept in the translated folder.
# So in order to achieve this, the script must check with the chatgpt 4.mini model the following rules:
# 1. We must make sure that the target_expression field is not empty and contains the translation of the source_expression for the target language.
# 2. It seems that in many cases the "target_pre_tag" or the "target_post_tag" is not empty and contains the translation of the "source_expression"
# 3. while the "target_expression" is either empty or contains wrong information.
# 4. It seems that in many cases with the LANGS_WITH_GENDER languages the "target_pre_tag" does not contain the correct article or gender determiner. So
# Definition:
#      "target_pre_tag"   — ONLY a short grammatical article or gender determiner only for languages like German, Spanish, French, Italian, Portuguese, Romanian, Arabic (one word, e.g. "der"/"die"/"das", "el"/"la", "un"/"une", "o"/"a").
#                          Use an empty string "" when the language has no grammatical gender OR when the expression is not a noun.
#                          ⚠ NEVER put the actual translation of the source_expression here. ⚠
#
#     "target_expression" — The FULL translation of the expression (source_expression). This field MUST NEVER be left empty.
#                           It always contains the translated word or phrase, without any article prefix.
#
#     "target_post_tag"  — For nouns: the plural form. For verbs: the past-tense / infinitive form. Empty string "" otherwise. ⚠ NEVER put the actual translation of the source_expression here. ⚠
# If the chatgpt 4.mini model signals a problem, the chatgpt model 5.4 shall be used to correct the problem., but only the problematic items must be corrected and translated and saved!

from __future__ import annotations

import argparse
import copy
import json
import logging
import os
import random
import sys
import time
from typing import Any

import httpx
import openai
from dotenv import load_dotenv

load_dotenv(override=True)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TRANSLATED_DIR = os.path.join(BASE_DIR, "translated_check")
CORRECTED_DIR = os.path.join(BASE_DIR, "translated_corrected")
DEFAULT_LOG_FILE = os.path.join(BASE_DIR, "correct_translated_tags.log")

_logger: logging.Logger | None = None


def setup_logging(log_path: str) -> logging.Logger:
    """Write UTF-8 log file; idempotent if called again with same path."""
    global _logger
    log = logging.getLogger("correct_translated_tags")
    log.setLevel(logging.DEBUG)
    log.handlers.clear()
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        )
    )
    log.addHandler(fh)
    log.propagate = False
    _logger = log
    return log


# Languages where target_pre_tag may be a noun article/determiner (not the lemma).
LANGS_WITH_GENDER = frozenset({"AR", "DE", "ES", "FR", "IT", "PT", "RO"})

MODEL_AUDIT = os.getenv("OPENAI_MODEL_AUDIT", "gpt-4.1-mini")
# MODEL_AUDIT = os.getenv("OPENAI_MODEL_AUDIT", "gpt-5.4")
MODEL_FIX = os.getenv("OPENAI_MODEL_FIX", "gpt-5.4")

AUDIT_BATCH_SIZE = 20
FIX_BATCH_SIZE = 10
API_RETRIES = int(os.getenv("OPENAI_API_RETRIES", "6"))
RETRY_DELAY_SEC = float(os.getenv("OPENAI_RETRY_DELAY_SEC", "2.0"))
RETRY_MAX_SLEEP_SEC = float(os.getenv("OPENAI_RETRY_MAX_SLEEP_SEC", "60"))
REQUEST_TIMEOUT_SEC = float(os.getenv("OPENAI_REQUEST_TIMEOUT_SEC", "90"))
LOG_AI_PAYLOAD_ON_ERROR = os.getenv("LOG_AI_PAYLOAD_ON_ERROR", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "y",
    "on",
}
LOG_AI_PAYLOAD_MAX_CHARS = int(os.getenv("LOG_AI_PAYLOAD_MAX_CHARS", "12000"))


def _client() -> openai.OpenAI:
    def _env_bool(name: str, default: bool) -> bool:
        v = os.getenv(name)
        if v is None:
            return default
        v = v.strip().lower()
        return v in {"1", "true", "yes", "y", "on"}

    key = os.getenv("OPENAI_API_KEY")
    if not key:
        print("ERROR: OPENAI_API_KEY is not set.", file=sys.stderr)
        sys.exit(1)
    # By default we *trust* proxy env vars (common in corp / WSL setups).
    # If you hit proxy issues, set OPENAI_TRUST_ENV=0 to bypass proxy env vars.
    trust_env = _env_bool("OPENAI_TRUST_ENV", True)
    http = httpx.Client(
        timeout=httpx.Timeout(REQUEST_TIMEOUT_SEC, connect=10.0),
        trust_env=trust_env,
    )
    return openai.OpenAI(api_key=key, http_client=http)


def iter_translated_json_files(root: str) -> list[str]:
    """Absolute paths to all .json files under root, sorted."""
    out: list[str] = []
    for dirpath, _, filenames in os.walk(root):
        for name in sorted(filenames):
            if name.endswith(".json"):
                out.append(os.path.join(dirpath, name))
    out.sort()
    return out


def rel_under_translated(abs_path: str) -> str:
    return os.path.relpath(abs_path, TRANSLATED_DIR)


def target_language_from_filename(path: str) -> str | None:
    """Parse target language from names like EN_HU_A2_Daily_routines_detailed_WORDS.json → HU.

    The second underscore-separated segment after the leading EN_ token is the target
    language code. This is the authoritative target language for auditing and fixing.
    """
    base = os.path.splitext(os.path.basename(path))[0]
    parts = base.split("_")
    if len(parts) >= 2 and parts[0].upper() == "EN":
        return parts[1].upper()
    return None


def part_a_item_fails(item: dict[str, Any]) -> bool:
    if not str(item.get("target_expression", "")).strip():
        return True
    examples = item.get("examples")
    if not isinstance(examples, list):
        return True
    for ex in examples:
        if not isinstance(ex, dict):
            return True
        if not str(ex.get("target", "")).strip():
            return True
    return False


def part_a_failure_detail(item: dict[str, Any]) -> str:
    """Human-readable reasons why Part A fails (empty string if passes)."""
    parts: list[str] = []
    if not str(item.get("target_expression", "")).strip():
        parts.append("empty target_expression")
    examples = item.get("examples")
    if not isinstance(examples, list):
        parts.append("examples is not a list")
        return "; ".join(parts)
    for j, ex in enumerate(examples):
        if not isinstance(ex, dict):
            parts.append(f"examples[{j}] not an object")
            continue
        if not str(ex.get("target", "")).strip():
            parts.append(f"examples[{j}].target empty")
    return "; ".join(parts)


def run_part_a(files: list[str], log: logging.Logger | None = None) -> list[str]:
    """Return paths (relative to TRANSLATED_DIR) of files that fail Part A."""
    failing: list[str] = []
    for path in files:
        rel = rel_under_translated(path)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            failing.append(rel)
            if log:
                log.warning("Part A | %s | top-level JSON is not a list", rel)
            continue
        for i, item in enumerate(data):
            if not isinstance(item, dict):
                continue
            if part_a_item_fails(item):
                if log:
                    log.warning(
                        "Part A | incorrect | %s | item[%d] | %s | source_expression=%r",
                        rel,
                        i,
                        part_a_failure_detail(item),
                        item.get("source_expression", ""),
                    )
        bad = any(part_a_item_fails(item) for item in data if isinstance(item, dict))
        if bad:
            failing.append(rel)
    return failing


def _audit_system_prompt() -> str:
    g = ", ".join(sorted(LANGS_WITH_GENDER))
    return f"""You QA-check vocabulary JSON items (English → target language).

The payload includes "file_target_language": this is the authoritative target language code for this file (from the filename). Use it for all judgements; ignore any mismatch with older JSON fields.

Grammatical-gender languages (articles/determiners may apply to nouns): {g}.
For other target languages, target_pre_tag is usually empty "".

Rules:
1. target_expression must be non-empty and the correct translation of source_expression for the target language (same meaning). It must NOT be only a fragment wrongly placed.
2. Each example "target" must be a proper translation of the corresponding "source" in the target language.
3. Each "target" element of the example sentences' list  must contain the target_expression (declination/conjugation is allowed), because the examples are sample sentences for the soure_expression and the target_expression.
If the "target" element of the example does not contain the target_expression, it is an error. — flag as NOT ok.
4. Common error: the source_expression is not translated but copied to the target_expression field — flag as NOT ok. Exclude international words as "email", "URL", etc.
5. Common error: the target_expression is empty — flag as NOT ok.
6. Common error: the "target" element in the example sentences' list is empy - flag as NOT ok.

Return a JSON object: {{"results": [{{"id": <int>, "ok": <bool>, "reason": "<brief, may be empty if ok>"}}]}}
Include one result per input id. Do not omit ids."""


# 2. target_pre_tag must be ONLY a short article or gender determiner (typically ONE word) when the head is a noun in a gendered language — NEVER the full translation of the source_expression or a phrase. If non-empty in a gendered language, it must not contain the lemma itself.
# 3. target_post_tag is plural (nouns) or verb-related form per conventions — NEVER the main translation of source_expression.


def _call_json(
    client: openai.OpenAI,
    model: str,
    system: str,
    user_payload: dict[str, Any],
) -> dict[str, Any]:
    def _extract_json_object(text: str) -> str | None:
        """Best-effort extraction of a JSON object from arbitrary text."""
        s = text.strip()
        if not s:
            return None
        # Strip common markdown fences.
        if s.startswith("```"):
            # remove leading ```json / ``` and trailing ```
            lines = s.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            s = "\n".join(lines).strip()
        # Fast path: looks like a JSON object already.
        if s.startswith("{") and s.endswith("}"):
            return s
        # Otherwise, try to grab the outermost {...} span.
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            return s[start : end + 1].strip()
        return None

    def _payload_for_log(payload: dict[str, Any]) -> str:
        """Compact but complete payload logging (truncated)."""
        try:
            rendered = json.dumps(payload, ensure_ascii=False)
        except Exception:
            rendered = repr(payload)
        if len(rendered) > LOG_AI_PAYLOAD_MAX_CHARS:
            return rendered[:LOG_AI_PAYLOAD_MAX_CHARS] + "…(truncated)"
        return rendered

    def _payload_items_for_log(payload: dict[str, Any]) -> str:
        """Log only the per-item rows we send to the model (truncated)."""
        try:
            items = payload.get("items", None)
            if not isinstance(items, list):
                return _payload_for_log(payload)
            compact = {
                "file_target_language": payload.get("file_target_language"),
                "items": items,
            }
            return _payload_for_log(compact)
        except Exception:
            return _payload_for_log(payload)

    def _is_timeout_error(exc: Exception) -> bool:
        return isinstance(exc, openai.APITimeoutError)

    # If the audit model stalls, try the fix model *once* for this call.
    allow_audit_timeout_fallback = model == MODEL_AUDIT and bool(MODEL_FIX)

    last_err: Exception | None = None
    for attempt in range(1, API_RETRIES + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system},
                    {
                        "role": "user",
                        "content": json.dumps(user_payload, ensure_ascii=False),
                    },
                ],
                response_format={"type": "json_object"},
                temperature=0.1,
                timeout=REQUEST_TIMEOUT_SEC,
            )
            raw = response.choices[0].message.content
            if not raw:
                raise ValueError("empty model content")
            try:
                return json.loads(raw)
            except json.JSONDecodeError as exc:
                # Sometimes the model returns fenced JSON or stray text despite response_format.
                # Log the raw content so we can see what caused it.
                if _logger is not None:
                    _logger.error(
                        "Model JSON parse failed (attempt %d/%d). model=%s error=%s raw=%r",
                        attempt,
                        API_RETRIES,
                        model,
                        str(exc),
                        raw[:4000],
                    )
                    if LOG_AI_PAYLOAD_ON_ERROR:
                        _logger.error(
                            "Model JSON parse failed | payload_items=%s",
                            _payload_items_for_log(user_payload),
                        )
                extracted = _extract_json_object(raw)
                if extracted and extracted != raw:
                    return json.loads(extracted)
                raise
        except Exception as exc:
            # One-shot fallback: audit model timeout → use fix model for this call only.
            if (
                allow_audit_timeout_fallback
                and _is_timeout_error(exc)
                and model == MODEL_AUDIT
                and MODEL_FIX != MODEL_AUDIT
            ):
                allow_audit_timeout_fallback = False
                if _logger is not None:
                    _logger.warning(
                        "Audit model timed out; falling back to MODEL_FIX for this call only "
                        "(audit=%s fix=%s).",
                        MODEL_AUDIT,
                        MODEL_FIX,
                    )
                try:
                    return _call_json(client, MODEL_FIX, system, user_payload)
                except Exception as exc2:
                    # Fall back failed; continue normal retry path on the audit model.
                    last_err = exc2
                    if _logger is not None:
                        _logger.warning(
                            "Fallback MODEL_FIX call also failed; continuing retries on audit model. "
                            "fix=%s err=%r",
                            MODEL_FIX,
                            exc2,
                        )

            last_err = exc
            if _logger is not None:
                _logger.warning(
                    "Model call failed (attempt %d/%d). model=%s err=%r",
                    attempt,
                    API_RETRIES,
                    model,
                    exc,
                )
                if LOG_AI_PAYLOAD_ON_ERROR:
                    _logger.warning(
                        "Model call failed | payload_items=%s",
                        _payload_items_for_log(user_payload),
                    )
            if attempt < API_RETRIES:
                # Exponential-ish backoff with jitter; cap to avoid unbounded sleeps.
                base = RETRY_DELAY_SEC * attempt * attempt
                sleep_s = min(RETRY_MAX_SLEEP_SEC, base) * (0.8 + 0.4 * random.random())
                time.sleep(sleep_s)
    raise last_err  # type: ignore[misc]


def audit_batch(
    client: openai.OpenAI,
    slice_items: list[tuple[int, dict[str, Any]]],
    target_language_code: str,
) -> tuple[dict[int, bool], dict[int, str]]:
    """Returns (needs_fix per id, audit reason per id from the model).

    target_language_code comes from the JSON filename (EN_<LANG>_...), not from item fields.
    """
    payload = {
        "file_target_language": target_language_code,
        "items": [
            {
                "id": i,
                "source_language": it.get("source_language", ""),
                "target_language": target_language_code,
                "source_pre_tag": it.get("source_pre_tag", ""),
                "source_expression": it.get("source_expression", ""),
                "source_post_tag": it.get("source_post_tag", ""),
                "target_pre_tag": it.get("target_pre_tag", ""),
                "target_expression": it.get("target_expression", ""),
                "target_post_tag": it.get("target_post_tag", ""),
                "examples": it.get("examples", []),
            }
            for i, it in slice_items
        ],
    }
    data = _call_json(client, MODEL_AUDIT, _audit_system_prompt(), payload)
    results = data.get("results", [])
    out: dict[int, bool] = {}
    reasons: dict[int, str] = {}
    for r in results:
        try:
            rid = int(r["id"])
            ok = bool(r.get("ok", True))
            out[rid] = not ok
            reasons[rid] = str(r.get("reason", "") or "").strip()
        except (KeyError, TypeError, ValueError):
            continue
    for i, _ in slice_items:
        out.setdefault(i, False)
        reasons.setdefault(i, "")
    return out, reasons


def _fix_system_prompt() -> str:
    g = ", ".join(sorted(LANGS_WITH_GENDER))
    return f"""You repair vocabulary JSON items. Grammatical-gender languages: {g}.

The user payload includes "file_target_language": the authoritative target language for this file (from the filename). Translate into that language; each item's "target_language" field matches it.

Each input item may include an optional string field "audit_feedback". When present, it states what a prior QA audit and/or automated validation flagged for that row. Treat it as the primary diagnosis: fix those specific problems while still obeying every field rule below. If "audit_feedback" is empty or missing, infer corrections only from the current field values and the rules.

Field rules:
1. target_expression must be non-empty and the correct translation of source_expression for the target language (same meaning), but check the source field of the examples as well in order to use a proper translation. It must NOT be only a fragment wrongly placed.
2. Each example "target" must be a proper translation of the corresponding "source" in the target language.
3. Each "target" element of the example sentences' list  must contain the target_expression (declination/conjugation is allowed), because the examples are sample sentences for the soure_expression and the target_expression.
If the "target" element of the example does not contain the target_expression, it is an error. .
4. examples: same length and order as input; each "target" translates the matching "source".
5. Common error: the source_expression is not translated but copied to the target_expression field — flag as NOT ok. Exclude international words as "email", "URL", etc.
6. Common error: the target_expression is empty — flag as NOT ok.
7. Common error: the "target" element in the example sentences' list is empy - flag as NOT ok.


Return JSON: {{"items": [{{"id": <int>, "target_expression": "...", "examples": [{{"target": "..."}}]}}]}}
Only include the ids you are asked to fix. Preserve categories and source fields — output only the fields above per item."""


def _fix_PRE_POST_tags_prompt() -> str:
    # this prompt will be used to fix the target_pre_tag and target_post_tag fields in case the target languate is one of the LANGS_WITH_GENDER.
    # g = ", ".join(sorted(LANGS_WITH_GENDER))
    return """You add only target_pre_tag and target_post_tag for vocabulary JSON items (English → target language).

The user payload includes "file_target_language": this is the authoritative target language code for this file.
You MUST output target_pre_tag/target_post_tag in that target language. Never output words from a different language.

You will receive items containing (at least):

id (int)
source_pre_tag (string, usually "")
source_expression (English headword/phrase)
source_post_tag (one of the allowed tags below)
target_expression (already translated lemma, do not change it)
target_examples (already translated example sentences, for context)
Allowed source_post_tag values (closed set): n., v., adj., adv., prep., conj., pron., interj., phrase, num., det., other

Definitions & rules you must follow:

You must NOT translate source_expression again.
You are not producing the main translation — that is target_expression and is already provided.

target_pre_tag = article/gender determiner
Output ONLY a short grammatical article or gender determiner (typically exactly one word) and only when: source_post_tag is n. (noun), and the target language uses grammatical gender/articles (e.g., German/Spanish/French/Italian/Portuguese/Romanian/Arabic). Otherwise output "".
Never include the noun itself, never output multiword noun phrases, and never output the translation of source_expression here.
Correct: "der", "die", "das", "el", "la", "un", "une", "o", "a"
Wrong: "el gato", "la tarde", "dezbaterea" (contains the noun)
target_post_tag (inflectional form; NEVER the lemma/infinitive):
- If source_post_tag is n.: output the plural form of the noun (dictionary citation plural). If plural is not used/doesn’t exist/unknown, output "".
- If source_post_tag is v.:
  - For German (file_target_language == "DE") specifically, output: "<Präteritum>, <aux>. <Partizip II>" where aux is "h." (haben) or "i." (sein).
    REQUIRED constraints for German verbs:
      - Must contain a comma and MUST contain either "h." or "i." (example: "…, h. …" or "…, i. …").
      - Must be Präteritum (simple past), NOT present tense.
      - Must NOT equal target_expression and must NOT be just the infinitive/lemma.
      - For separable verbs, Präteritum typically places the prefix at the end (e.g. "rief an", "schloss ab").
      - If unsure, output "" (do NOT guess).
    Examples:
      - gehen → "ging, i. gegangen"
      - machen → "machte, h. gemacht"
      - abschließen → "schloss ab, h. abgeschlossen"
      - anrufen → "rief an, h. angerufen"
      - bezahlen → "bezahlte, h. bezahlt"
      - planen → "plante, h. geplant"
  - For all other target languages (file_target_language != "DE"): output "" for verbs (do NOT invent verb forms).
- For all other source_post_tag values: output "".
Never put the full translation of source_expression here. Never copy target_expression into target_post_tag, and never repeat the lemma.
Use target_examples only to disambiguate part of speech and sense (e.g., noun vs verb usage), and to pick the correct article/plural/verb form for that sense.

Output must be valid JSON only (no commentary, no markdown, no extra keys).

Return JSON exactly in this schema (and include one entry per input id): { "items": [ { "id": , "target_pre_tag": "", "target_post_tag": "" } ] }"""


def _snapshot_item_tags(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "target_pre_tag": item.get("target_pre_tag", ""),
        "target_expression": item.get("target_expression", ""),
        "target_post_tag": item.get("target_post_tag", ""),
        "examples": copy.deepcopy(item.get("examples", [])),
    }


def _fix_hint_for_item(
    idx: int,
    items: list[Any],
    audit_bad: set[int],
    part_a_bad: set[int],
    audit_reasons_by_index: dict[int, str],
) -> str:
    """Human-readable hint for the fix model (audit reason, Part A detail, or both)."""
    parts: list[str] = []
    if idx in audit_bad:
        r = str(audit_reasons_by_index.get(idx, "") or "").strip()
        if r:
            parts.append(f"Prior QA audit: {r}")
    if idx in part_a_bad:
        it = items[idx]
        if isinstance(it, dict):
            d = part_a_failure_detail(it).strip()
            if d:
                parts.append(f"Automated check: {d}")
    return " | ".join(parts)


def fix_items_batch(
    client: openai.OpenAI,
    full_items: list[dict[str, Any]],
    ids_to_fix: list[int],
    target_language_code: str,
    log: logging.Logger | None,
    rel_file: str,
    audit_feedback_by_id: dict[int, str],
) -> None:
    """Apply corrections in-place on full_items for the given ids.

    target_language_code is taken from the filename (EN_<LANG>_...), not item JSON.
    """
    before: dict[int, dict[str, Any]] = {}
    for i in ids_to_fix:
        it = full_items[i]
        if isinstance(it, dict):
            before[i] = _snapshot_item_tags(it)

    batch = []
    for i in ids_to_fix:
        it = full_items[i]
        feedback = str(audit_feedback_by_id.get(i, "") or "").strip()
        row: dict[str, Any] = {
            "id": i,
            "source_language": it.get("source_language", ""),
            "target_language": target_language_code,
            "source_pre_tag": it.get("source_pre_tag", ""),
            "source_expression": it.get("source_expression", ""),
            "source_post_tag": it.get("source_post_tag", ""),
            "target_pre_tag": it.get("target_pre_tag", ""),
            "target_expression": it.get("target_expression", ""),
            "target_post_tag": it.get("target_post_tag", ""),
            "examples": it.get("examples", []),
        }
        if feedback:
            row["audit_feedback"] = feedback
        batch.append(row)
    data = _call_json(
        client,
        MODEL_FIX,
        _fix_system_prompt(),
        {"file_target_language": target_language_code, "items": batch},
    )
    for fixed in data.get("items", []):
        try:
            idx = int(fixed["id"])
        except (KeyError, TypeError, ValueError):
            continue
        if idx < 0 or idx >= len(full_items):
            continue
        row = full_items[idx]
        if "target_pre_tag" in fixed:
            row["target_pre_tag"] = fixed["target_pre_tag"]
        if "target_expression" in fixed:
            row["target_expression"] = fixed["target_expression"]
        if "target_post_tag" in fixed:
            row["target_post_tag"] = fixed["target_post_tag"]
        if "examples" in fixed and isinstance(fixed["examples"], list):
            sources = row.get("examples", [])
            if isinstance(sources, list):
                new_ex = []
                for j, ex in enumerate(sources):
                    if not isinstance(ex, dict):
                        continue
                    src = ex.get("source", "")
                    tgt = ex.get("target", "")
                    if j < len(fixed["examples"]) and isinstance(
                        fixed["examples"][j], dict
                    ):
                        tgt = fixed["examples"][j].get("target", tgt)
                    new_ex.append({"source": src, "target": tgt})
                row["examples"] = new_ex

        if log and idx in before:
            after = _snapshot_item_tags(row)
            prev = before[idx]
            if after != prev:
                log.info(
                    "Corrected | %s | item[%d] | source_expression=%r\n  before: %s\n  after:  %s",
                    rel_file,
                    idx,
                    row.get("source_expression", ""),
                    json.dumps(prev, ensure_ascii=False),
                    json.dumps(after, ensure_ascii=False),
                )
            else:
                log.info(
                    "Corrected (unchanged output) | %s | item[%d] | source_expression=%r",
                    rel_file,
                    idx,
                    row.get("source_expression", ""),
                )


def fix_pre_post_tags_batch(
    client: openai.OpenAI,
    full_items: list[Any],
    ids_to_fix: list[int],
    target_language_code: str,
    log: logging.Logger | None,
    rel_file: str,
) -> None:
    """Update only target_pre_tag/target_post_tag in-place for the given ids."""

    def _strip_leading_article(lang: str, s: str) -> str:
        """Remove leading standalone articles/determiners from noun plurals.

        Applies only to languages where articles are typically separate tokens.
        """
        txt = (s or "").strip()
        if not txt:
            return txt
        low = txt.casefold()

        articles_by_lang: dict[str, tuple[str, ...]] = {
            "DE": (
                "der ",
                "die ",
                "das ",
                "den ",
                "dem ",
                "des ",
                "ein ",
                "eine ",
                "einen ",
                "einem ",
                "einer ",
            ),
            "ES": ("el ", "la ", "los ", "las ", "un ", "una ", "unos ", "unas "),
            "FR": ("le ", "la ", "les ", "un ", "une ", "des ", "l'"),
            "IT": (
                "il ",
                "lo ",
                "la ",
                "i ",
                "gli ",
                "le ",
                "un ",
                "uno ",
                "una ",
                "un'",
            ),
            "PT": ("o ", "a ", "os ", "as ", "um ", "uma ", "uns ", "umas "),
        }

        for art in articles_by_lang.get(lang, ()):
            if low.startswith(art):
                return txt[len(art) :].strip()
        return txt

    def _de_verb_post_tag_prompt() -> str:
        return """You produce ONLY German verb principal parts for learner vocabulary items.

Input items include:
- id (int)
- target_expression (German lemma/infinitive; separable verbs may appear as one word like "anrufen" or as two words like "sich ausruhen")
- target_examples (German example sentence(s), for context only)

Task:
For each item, return target_post_tag as: "<Präteritum>, <aux>. <Partizip II>"
Where aux is exactly "h." (haben) or "i." (sein).

Hard constraints (must follow):
- Output MUST contain a comma and MUST contain either " h. " or " i. ".
- Output MUST NOT equal target_expression.
- Use Präteritum (simple past), NOT present tense.
- For separable verbs, the Präteritum form usually separates the prefix (e.g. "anrufen" → "rief an", "abschließen" → "schloss ab").
- If you are not sure, output "" (empty string). Do NOT guess.

Return valid JSON only:
{"items": [{"id": 1, "target_post_tag": "..." }]}"""

    before: dict[int, dict[str, Any]] = {}
    for i in ids_to_fix:
        it = full_items[i]
        if isinstance(it, dict):
            before[i] = _snapshot_item_tags(it)

    batch: list[dict[str, Any]] = []
    lemma_by_id: dict[int, str] = {}
    for i in ids_to_fix:
        it = full_items[i]
        if not isinstance(it, dict):
            continue
        lemma = str(it.get("target_expression", "") or "").strip()
        lemma_by_id[i] = lemma
        batch.append(
            {
                "id": i,
                "source_language": it.get("source_language", ""),
                "target_language": target_language_code,
                "source_pre_tag": it.get("source_pre_tag", ""),
                "source_expression": it.get("source_expression", ""),
                "source_post_tag": it.get("source_post_tag", ""),
                "target_expression": lemma,
                "target_examples": it.get("examples", []),
                "target_pre_tag": it.get("target_pre_tag", ""),
                "target_post_tag": it.get("target_post_tag", ""),
            }
        )

    if not batch:
        return

    data = _call_json(
        client,
        MODEL_AUDIT,
        _fix_PRE_POST_tags_prompt(),
        {"file_target_language": target_language_code, "items": batch},
    )
    for fixed in data.get("items", []):
        try:
            idx = int(fixed["id"])
        except (KeyError, TypeError, ValueError):
            continue
        if idx < 0 or idx >= len(full_items):
            continue
        row = full_items[idx]
        if not isinstance(row, dict):
            continue
        if "target_pre_tag" in fixed:
            row["target_pre_tag"] = fixed["target_pre_tag"]
        if "target_post_tag" in fixed:
            row["target_post_tag"] = fixed["target_post_tag"]

        # Guardrails: the model may still output invalid post-tags.
        src_pos = str(row.get("source_post_tag", "") or "").strip()
        lemma = str(
            lemma_by_id.get(idx, row.get("target_expression", "")) or ""
        ).strip()
        post = str(row.get("target_post_tag", "") or "").strip()

        if (
            src_pos == "n."
            and post
            and target_language_code in {"DE", "ES", "FR", "IT", "PT"}
        ):
            cleaned = _strip_leading_article(target_language_code, post)
            if cleaned != post:
                post = cleaned
                row["target_post_tag"] = post

        # Policy: only German verb post-tags are supported.
        # For other languages, keep verbs empty to prevent cross-language contamination
        # (e.g. German forms leaking into ES/FR/... files).
        if target_language_code != "DE" and src_pos == "v.":
            if post:
                row["target_post_tag"] = ""
                if log:
                    log.warning(
                        "PRE/POST blanked non-DE verb post_tag | %s | item[%d] | target=%s | lemma=%r | got=%r",
                        rel_file,
                        idx,
                        target_language_code,
                        lemma,
                        post,
                    )
            post = ""

        if target_language_code == "DE" and src_pos == "v.":
            # German verb principal parts must not be the lemma and should include aux marker.
            invalid = False
            if not post:
                invalid = False
            else:
                if lemma and post == lemma:
                    invalid = True
                if "," not in post:
                    invalid = True
                if (" h." not in post) and (" i." not in post):
                    invalid = True
                if "->" in post:
                    invalid = True
            if invalid:
                row["target_post_tag"] = ""
                if log:
                    log.warning(
                        "PRE/POST invalid verb post_tag | %s | item[%d] | lemma=%r | got=%r → blanked",
                        rel_file,
                        idx,
                        lemma,
                        post,
                    )

        if log and idx in before:
            after = _snapshot_item_tags(row)
            prev = before[idx]
            if after != prev:
                log.info(
                    "Corrected PRE/POST | %s | item[%d] | source_expression=%r\n  before: %s\n  after:  %s",
                    rel_file,
                    idx,
                    row.get("source_expression", ""),
                    json.dumps(prev, ensure_ascii=False),
                    json.dumps(after, ensure_ascii=False),
                )

    # Second chance: for DE verbs still missing target_post_tag, retry with MODEL_FIX and a
    # verb-only principal-parts prompt.
    if target_language_code == "DE":
        retry_ids: list[int] = []
        for i in ids_to_fix:
            it = full_items[i]
            if not isinstance(it, dict):
                continue
            if str(it.get("source_post_tag", "") or "").strip() != "v.":
                continue
            if str(it.get("target_post_tag", "") or "").strip():
                continue
            if not str(it.get("target_expression", "") or "").strip():
                continue
            retry_ids.append(i)

        if retry_ids:
            retry_batch = [
                {
                    "id": i,
                    "target_expression": str(
                        (full_items[i] or {}).get("target_expression", "")  # type: ignore[union-attr]
                    ).strip(),
                    "target_examples": (full_items[i] or {}).get("examples", []),  # type: ignore[union-attr]
                }
                for i in retry_ids
                if isinstance(full_items[i], dict)
            ]
            data2 = _call_json(
                client,
                MODEL_FIX,
                _de_verb_post_tag_prompt(),
                {"items": retry_batch},
            )
            for fixed in data2.get("items", []):
                try:
                    idx = int(fixed["id"])
                except (KeyError, TypeError, ValueError):
                    continue
                if idx not in retry_ids:
                    continue
                row = full_items[idx]
                if not isinstance(row, dict):
                    continue
                lemma = str(row.get("target_expression", "") or "").strip()
                post = str(fixed.get("target_post_tag", "") or "").strip()
                if not post:
                    continue
                if post == lemma:
                    continue
                if "," not in post:
                    continue
                if (" h. " not in f" {post} ") and (" i. " not in f" {post} "):
                    continue
                row["target_post_tag"] = post
                if log:
                    log.info(
                        "Filled DE verb post_tag | %s | item[%d] | lemma=%r | target_post_tag=%r",
                        rel_file,
                        idx,
                        lemma,
                        post,
                    )


def process_file_ai(
    client: openai.OpenAI,
    src_path: str,
    dest_path: str,
    dry_run: bool,
    log: logging.Logger | None = None,
) -> tuple[int, int]:
    """Returns (items_flagged_by_audit_or_part_a, items_written_fixed)."""
    rel = rel_under_translated(src_path)
    target_lang = target_language_from_filename(src_path)
    if not target_lang:
        print(
            f"  SKIP (cannot parse EN_<LANG>_ from filename): {rel}",
            file=sys.stderr,
        )
        if log:
            log.warning("SKIP | %s | cannot parse EN_<LANG>_ from filename", rel)
        return 0, 0

    with open(src_path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        print(f"  SKIP (not a list): {rel}")
        if log:
            log.warning("SKIP | %s | top-level JSON is not a list", rel)
        return 0, 0

    items: list[Any] = data
    n_dict = sum(1 for it in items if isinstance(it, dict))
    print(f"  ▸ {rel} | target={target_lang} | {n_dict} items …", flush=True)
    mismatch_warned = False
    for it in items:
        if not isinstance(it, dict):
            continue
        json_lang = str(it.get("target_language", "")).strip().upper()
        if json_lang and json_lang != target_lang and not mismatch_warned:
            print(
                f"  NOTE: {rel}: JSON target_language "
                f"({json_lang}) differs from filename ({target_lang}); using filename.",
                file=sys.stderr,
            )
            if log:
                log.warning(
                    "NOTE | %s | JSON target_language %s != filename %s (using filename)",
                    rel,
                    json_lang,
                    target_lang,
                )
            mismatch_warned = True
        it["target_language"] = target_lang

    part_a_bad = {
        i
        for i, it in enumerate(items)
        if isinstance(it, dict) and part_a_item_fails(it)
    }
    if log and part_a_bad:
        for i in sorted(part_a_bad):
            it = items[i]
            if isinstance(it, dict):
                log.warning(
                    "Part A | incorrect | %s | item[%d] | %s | source_expression=%r",
                    rel,
                    i,
                    part_a_failure_detail(it),
                    it.get("source_expression", ""),
                )

    dict_indices = [i for i, it in enumerate(items) if isinstance(it, dict)]
    n_audit_batches = (
        (len(dict_indices) + AUDIT_BATCH_SIZE - 1) // AUDIT_BATCH_SIZE
        if dict_indices
        else 0
    )
    audit_bad: set[int] = set()
    audit_reasons_by_index: dict[int, str] = {}
    audit_num = 0
    for start in range(0, len(dict_indices), AUDIT_BATCH_SIZE):
        audit_num += 1
        idxs = dict_indices[start : start + AUDIT_BATCH_SIZE]
        chunk = [(i, items[i]) for i in idxs]
        print(
            f"    [{rel}] audit batch {audit_num}/{n_audit_batches} "
            f"({len(chunk)} items, indices {idxs[0]}–{idxs[-1]}) …",
            flush=True,
        )
        id_map, audit_reasons = audit_batch(client, chunk, target_lang)
        for i in idxs:
            audit_reasons_by_index[i] = str(audit_reasons.get(i, "") or "").strip()
        for i, needs in id_map.items():
            if needs:
                # we need to check if the s contains "EXPRESSION"
                if "EXPRESSION" in rel:
                    if "target_post_tag is empty" in audit_reasons.get(i, ""):
                        continue
                    if "target_expression is too long" in audit_reasons.get(i, ""):
                        continue
                    if "target_pre_tag is empty" in audit_reasons.get(i, ""):
                        continue
                    if (
                        "target_pre_tag should be empty in this context"
                        in audit_reasons.get(i, "")
                    ):
                        continue
                    if "target_post_tag is incorrect" in audit_reasons.get(i, ""):
                        continue
                    if (
                        "target_pre_tag should be empty in this case"
                        in audit_reasons.get(i, "")
                    ):
                        continue
                    if "target_pre_tag contains the lemma itself" in audit_reasons.get(
                        i, ""
                    ):
                        continue
                if "WORDS" in rel:
                    if (
                        "target_expression is correct but target_post_tag is empty"
                        in audit_reasons.get(i, "")
                    ):
                        continue
                    if (
                        "target_expression should not be a phrase; it should be a single word"
                        in audit_reasons.get(i, "")
                    ):
                        continue
                    if "target_pre_tag is empty" in audit_reasons.get(i, ""):
                        continue
                    if "target_post_tag is empty" in audit_reasons.get(i, ""):
                        continue
                    if "target_post_tag contains" in audit_reasons.get(i, ""):
                        continue
                audit_bad.add(i)
                if log:
                    log.warning(
                        "Audit | incorrect | %s | item[%d] | %s | source_expression=%r",
                        rel,
                        i,
                        audit_reasons.get(i) or "(no reason from model)",
                        (
                            items[i].get("source_expression", "")
                            if isinstance(items[i], dict)
                            else ""
                        ),
                    )

    to_fix = sorted(part_a_bad | audit_bad)
    if not to_fix:
        if not dry_run:
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            with open(dest_path, "w", encoding="utf-8") as out:
                json.dump(items, out, ensure_ascii=False, indent=2)
                out.write("\n")
        if log:
            log.info(
                "OK | %s | target=%s | items=%d | nothing to fix",
                rel,
                target_lang,
                n_dict,
            )
        return 0, 0

    if dry_run:
        print(
            f"  WOULD FIX {len(to_fix)} item(s) in {rel} "
            f"(Part A: {len(part_a_bad)}, audit: {len(audit_bad - part_a_bad)})"
        )
        if log:
            log.info(
                "Dry-run | %s | would fix %d item(s) | Part A=%d | audit-only=%d | indices=%s",
                rel,
                len(to_fix),
                len(part_a_bad),
                len(audit_bad - part_a_bad),
                to_fix,
            )
        return len(to_fix), len(to_fix)

    audit_feedback_by_id: dict[int, str] = {
        i: _fix_hint_for_item(i, items, audit_bad, part_a_bad, audit_reasons_by_index)
        for i in to_fix
    }

    n_fix_batches = (len(to_fix) + FIX_BATCH_SIZE - 1) // FIX_BATCH_SIZE
    fix_num = 0
    for start in range(0, len(to_fix), FIX_BATCH_SIZE):
        fix_num += 1
        batch_ids = to_fix[start : start + FIX_BATCH_SIZE]
        print(
            f"    [{rel}] fix batch {fix_num}/{n_fix_batches} "
            f"({len(batch_ids)} items, indices {batch_ids[0]}–{batch_ids[-1]}) …",
            flush=True,
        )
        fix_items_batch(
            client,
            items,
            batch_ids,
            target_lang,
            log,
            rel,
            audit_feedback_by_id,
        )

    # For WORDS files in grammatical-gender languages, (re)derive target_pre_tag and
    # target_post_tag for *all* noun/verb items after the main corrections.
    if "WORDS" in rel and target_lang in LANGS_WITH_GENDER:
        pre_post_ids = [
            i
            for i, it in enumerate(items)
            if isinstance(it, dict) and it.get("source_post_tag") in {"n.", "v."}
        ]
        if pre_post_ids:
            n_pp_batches = (len(pre_post_ids) + FIX_BATCH_SIZE - 1) // FIX_BATCH_SIZE
            pp_num = 0
            for start in range(0, len(pre_post_ids), FIX_BATCH_SIZE):
                pp_num += 1
                batch_ids = pre_post_ids[start : start + FIX_BATCH_SIZE]
                print(
                    f"    [{rel}] pre/post batch {pp_num}/{n_pp_batches} "
                    f"({len(batch_ids)} items, indices {batch_ids[0]}–{batch_ids[-1]}) …",
                    flush=True,
                )
                fix_pre_post_tags_batch(
                    client,
                    items,
                    batch_ids,
                    target_lang,
                    log,
                    rel,
                )

    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    with open(dest_path, "w", encoding="utf-8") as out:
        json.dump(items, out, ensure_ascii=False, indent=2)
        out.write("\n")
    if log:
        log.info(
            "Saved | %s | wrote %d corrected item(s) → %s",
            rel,
            len(to_fix),
            os.path.relpath(dest_path, BASE_DIR),
        )

    return len(to_fix), len(to_fix)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate translated JSON (Part A) and optionally AI-correct (Part B)."
    )
    parser.add_argument(
        "--part-a-only",
        action="store_true",
        help="Only run Python checks and list failing files.",
    )
    parser.add_argument(
        "--part-b-only",
        action="store_true",
        help="Only run AI audit + fix (skip Part A report).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Part B: audit only, print counts; do not write translated_corrected.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Process at most N JSON files (0 = all).",
    )
    parser.add_argument(
        "--log-file",
        default=DEFAULT_LOG_FILE,
        help=f"Append detailed log (default: {DEFAULT_LOG_FILE}).",
    )
    parser.add_argument(
        "--no-log-file",
        action="store_true",
        help="Disable writing the log file.",
    )
    parser.add_argument(
        "--continue-on-api-error",
        action="store_true",
        help=(
            "If an API call fails after retries (502/timeouts/etc.), skip that file and continue "
            "processing the remaining files (still logs the failure)."
        ),
    )
    args = parser.parse_args()

    if not os.path.isdir(TRANSLATED_DIR):
        print(f"ERROR: missing folder: {TRANSLATED_DIR}", file=sys.stderr)
        sys.exit(1)

    file_log: logging.Logger | None = None
    if not args.no_log_file:
        file_log = setup_logging(args.log_file)
        file_log.info(
            "Session start | argv=%s",
            " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "(none)",
        )
        print(f"Logging to: {args.log_file}")

    files = iter_translated_json_files(TRANSLATED_DIR)
    if args.limit and args.limit > 0:
        files = files[: args.limit]

    if not args.part_b_only:
        print(f"Part A — scanned {len(files)} JSON file(s).")
        failing = run_part_a(
            files,
            log=file_log if args.part_a_only and file_log else None,
        )
        print("Files with empty target_expression or empty example target(s):")
        if failing:
            for p in failing:
                print(f"  {p}")
            print(f"Total: {len(failing)} file(s).")
        else:
            print("  (none)")
        if args.part_a_only:
            if file_log:
                file_log.info(
                    "Session end (Part A only) | failing files=%d", len(failing)
                )
            return

    client = _client()
    print(
        f"\nPart B — audit model: {MODEL_AUDIT}, fix model: {MODEL_FIX}"
        + (" (dry-run)" if args.dry_run else "")
    )
    if file_log:
        file_log.info(
            "Part B | audit=%s | fix=%s | dry_run=%s",
            MODEL_AUDIT,
            MODEL_FIX,
            args.dry_run,
        )
    n_files = 0
    total_fixed = 0
    for path in files:
        rel = rel_under_translated(path)
        dest = os.path.join(CORRECTED_DIR, rel)
        try:
            flagged, fixed = process_file_ai(
                client, path, dest, args.dry_run, log=file_log
            )
        except Exception as exc:
            if file_log:
                file_log.error(
                    "File failed due to API/runtime error | %s | err=%r", rel, exc
                )
            if args.continue_on_api_error:
                print(f"  {rel}: ERROR (skipped due to API/runtime error)")
                n_files += 1
                continue
            raise
        if flagged or fixed:
            print(f"  {rel}: corrected {fixed} item(s)")
            total_fixed += fixed
        n_files += 1
    print(f"\nProcessed {n_files} file(s). Total items corrected: {total_fixed}.")
    print(f"Output directory: {CORRECTED_DIR}")
    if file_log:
        file_log.info(
            "Session end | files=%d | total items corrected=%d",
            n_files,
            total_fixed,
        )


if __name__ == "__main__":
    main()
